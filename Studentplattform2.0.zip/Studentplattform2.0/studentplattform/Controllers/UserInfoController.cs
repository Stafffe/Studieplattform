﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace Studentplattform.Controllers
{
    public class UserInfoController : Controller
    {
        public static int GetUserId(string email)
        {
            StudieDbEntities db = new StudieDbEntities();
            return db.Users.FirstOrDefault(user => user.E_mail == email).Id;
        }

        public static bool IsAdmin(string email)
        {
            MyRoleProvider mrp = new MyRoleProvider();
            string[] roles = mrp.GetRolesForUser(email);
            if (roles.Contains("Admin"))
                return true;
            else
                return false;
        }

        public static bool SendEmail(int reciverUserId, string message, string messageTitle)
        {
            StudieDbEntities db = new StudieDbEntities();
            string email = db.Users.AsEnumerable().Where(u => u.Id == reciverUserId).Select(u => u.E_mail).FirstOrDefault();
            db.Dispose();
            try
            {
                MailMessage mail = new MailMessage();

                mail.From = new MailAddress("Studeplattformen@gmail.com");
                mail.To.Add(email);
                mail.Subject = messageTitle;
                mail.Body = message;


                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential("studieplattformen@gmail.com", "Laxpudding12");

                client.Send(mail);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public static bool SendMultipleEmail(int[] reciverUserId, string message, string messageTitle)
        {
            StudieDbEntities db = new StudieDbEntities();
            string[] emails = db.Users.AsEnumerable().Where(u => reciverUserId.Contains(u.Id)).Select(u => u.E_mail).ToArray();
            db.Dispose();
            try
            {
                MailMessage mail = new MailMessage();

                mail.From = new MailAddress("Studeplattformen@gmail.com");
                foreach (string email in emails)
                    mail.To.Add(email);
                mail.Subject = messageTitle;
                mail.Body = message;


                SmtpClient client = new SmtpClient("smtp.gmail.com", 587);
                client.EnableSsl = true;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Credentials = new NetworkCredential("studieplattformen@gmail.com", "Laxpudding12");

                client.Send(mail);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }
    }
}