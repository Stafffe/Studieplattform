﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Studentplattform.Models;
using System.Web.Security;
using System.Security.Principal;
using System.Security.Claims;
using System.Threading;
using Microsoft;

namespace Studentplattform.Controllers
{
    public class LoginRegisterController : Controller
    {
        // GET: LoginRegister
        [Authorize]
        public ActionResult MyPages()
        {
            StudieDbEntities db = new StudieDbEntities();
            int userId = UserInfoController.GetUserId(User.Identity.Name);
            Users loggedUser = db.Users.Where(u => u.Id == userId).FirstOrDefault();

            TempData["Username"] = loggedUser.Username;
            return View();
        }


        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Login(LoginUserModel user)
        {
            if (ModelState.IsValid)
            {
                bool? validLog = validLogin(user.Email, user.Password) == true;
                if(validLog == null)
                {
                    TempData["Message"] = "Det här kontot är avstängt";
                    return View();
                }
                if (validLog == true)
                {
                    TempData["Message"] = "Inloggning lyckades!";
                    FormsAuthentication.SetAuthCookie(user.Email, false);
                    return RedirectToAction("MyCourses", "MyCourses");
                }
                else
                {
                    ModelState.AddModelError("", "Lösenordet och emailen matchar inte");
                }
            }
            return View();

        }

        public bool? validLogin(string email, string password)
        {
            var crypto = new SimpleCrypto.PBKDF2();
            bool isValid = false;
            using (var db = new StudieDbEntities())
            {
                var user = db.Users.FirstOrDefault(u => u.E_mail == email);

                if (user.Role == null)
                    return null;

                if (user != null)
                {
                    if (user.Password == crypto.Compute(password, user.PasswordSalt))
                    {
                        isValid = true;
                    }
                }
            }

            return isValid;
        }

        [Authorize]
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            TempData["Message"] = "Du är nu utloggad!";
            return RedirectToAction("Login", "LoginRegister");
        }








        public ActionResult Register(string email=null, string username=null)
        {
            var user = new RegisterUserModel();
            user.Email = email;
            user.Username = username;
            return View(user);
        }

        [HttpPost]
        public ActionResult Register(RegisterUserModel user)
        {
            if (ModelState.IsValid)
                return View("Register2", user);
            else
                return View(user);
        }

        public ActionResult TillbaksRegister(RegisterUserModel user)
        {
            return RedirectToAction("Register", "LoginRegister", new { email = user.Email, username = user.Username });
        }

        public JsonResult IsEmailAvailable(string email)
        {
            StudieDbEntities dataB = new StudieDbEntities();
            return Json(!dataB.Users.Any(user => user.E_mail == email), JsonRequestBehavior.AllowGet);
        }

        public JsonResult IsUsernameAvailable(string username)
        {
            StudieDbEntities dataB = new StudieDbEntities();
            return Json(!dataB.Users.Any(user => user.Username == username), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Register2(RegisterUserModel user)
        {
            return View("Register2", user);
        }

        public ActionResult RegisterUser(RegisterUserModel user)
        {
            try
            {
                using (var db = new StudieDbEntities())
                {
                    var crypto = new SimpleCrypto.PBKDF2();
                    var cryptPass = crypto.Compute(user.Password);
                    var dbUser = db.Users.Create();

                    dbUser.E_mail = user.Email;
                    dbUser.Username = user.Username;
                    dbUser.Password = cryptPass;
                    dbUser.PasswordSalt = crypto.Salt;
                    dbUser.Role = 1;

                    db.Users.Add(dbUser);
                    db.SaveChanges();

                    TempData["Message"] = "Registrering lyckades!";

                    return View("Login");
                }
            }
            catch (Exception e)
            {
                ModelState.Clear();
                TempData["Error"] = "<div class='validMessage'> Ett oväntat fel inträffade</div>";
                return RedirectToAction("Register", "LoginRegister");
            }
        }










        [HttpPost]
        [Authorize]
        public ActionResult MyPages(ChangeUserInfoModel Model)
        {
            if (Model.ChangeWhat == 0)
            {
                try
                {
                    UpdateModel(Model.UsernameModel);
                }
                catch (Exception e) { }
                if (ModelState.IsValid)
                {
                    StudieDbEntities db = new StudieDbEntities();
                    int userId = UserInfoController.GetUserId(User.Identity.Name);
                    Users loggedUser = db.Users.Where(u => u.Id == userId).FirstOrDefault();
                    loggedUser.Username = Model.UsernameModel.Username;
                    try
                    {
                        TempData["Username"] = Model.UsernameModel.Username;
                        TempData["Message"] = "Användarnamnet ändrat";
                        db.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        TempData["Message"] = "Något gick fel med sparningen";
                    }

                    RedirectToAction("Index", "Home");
                }
                else
                {
                    TempData["Message"] = "Valideringen misslyckades";
                    return View();
                }
            }
            else if(Model.ChangeWhat == 1)
            {
                {
                    StudieDbEntities db = new StudieDbEntities();
                    int userId = UserInfoController.GetUserId(User.Identity.Name);
                    Users loggedUser = db.Users.Where(u => u.Id == userId).FirstOrDefault();
                    TempData["Username"] = loggedUser.Username;
                    try
                    {
                        UpdateModel(Model.PasswordModel);
                    }
                    catch (Exception e) { }
                    if (ModelState.IsValid)
                    {
                        if(!CorrectPassword(Model.PasswordModel.Password))
                        {
                            TempData["Message"] = "Det gamla lösenordet stämde inte";
                            return View();
                        }
                        var crypto = new SimpleCrypto.PBKDF2();
                        var cryptPass = crypto.Compute(Model.PasswordModel.PasswordNew);
                        loggedUser.Password = cryptPass;
                        loggedUser.PasswordSalt = crypto.Salt;

                        try
                        {
                            db.SaveChanges();
                            TempData["Message"] = "Lösenord ändrat";
                        }
                        catch (Exception e)
                        {
                            TempData["Message"] = "Något gick fel med sparningen";
                        }
                        RedirectToAction("Index", "Home");
                    }
                    else
                        return View();
                }
            }
            return View();
        }

        [HttpPost]
        [Authorize]
        public ActionResult ChangePassword(ChangeUserInfoModel Model)
        {
            return View();
        }

        [Authorize]
        public bool CorrectPassword(string password)
        {
            var crypto = new SimpleCrypto.PBKDF2();
            StudieDbEntities db = new StudieDbEntities();
            int userId = UserInfoController.GetUserId(User.Identity.Name);
            Users user = db.Users.Where(u => u.Id == userId).FirstOrDefault();

            if (user != null)
            {
                if (user.Password == crypto.Compute(password, user.PasswordSalt))
                {
                    return true;
                }
            }
            return false;
        }

    }
}