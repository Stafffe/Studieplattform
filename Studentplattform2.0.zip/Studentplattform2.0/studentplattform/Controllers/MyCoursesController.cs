﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Studentplattform.Models;

namespace Studentplattform.Controllers
{
    [Authorize]
    public class MyCoursesController : Controller
    {
        // GET: MyCourses
        public ActionResult MyCourses()
        {
            int userId = UserInfoController.GetUserId(User.Identity.Name);
            MyCoursesModel myCourses = new MyCoursesModel();
            StudieDbEntities db = new StudieDbEntities();

            int[] courseIds = db.TeachersForCourse.AsEnumerable().Where(tfc => tfc.UserId == userId).Select(tfc => tfc.CourseId).ToArray();
            myCourses.MyOwnedCourses = db.Courses.Where(c => courseIds.Contains(c.Id)).ToArray();

            int[] courseIds2 = db.StudentsInCourse.AsEnumerable().Where(sic => sic.UserId == userId).Select(sic => sic.CourseId).ToArray();
            myCourses.CoursesImIn = db.Courses.Where(c => courseIds2.Contains(c.Id)).ToArray();

            return View(myCourses);
        }

        public ActionResult NewCourse()
        {
            return View(GetTeachers());
        }

        public ActionResult RegisterToCourse(int courseId)
        {
            StudieDbEntities db = new StudieDbEntities();
            StudentsInCourse sic = new StudentsInCourse() { CourseId = courseId, UserId = UserInfoController.GetUserId(User.Identity.Name) };
            try
            {
                db.StudentsInCourse.Add(sic);
                db.SaveChanges();
                TempData["Message"] = "Du är nu registrerad till kursen";
            }
            catch(Exception e)
            {
                TempData["Message"] = "Något gick fel";
            }
            return RedirectToAction("ShowCourse", "MyCourses", new { courseId = courseId });
        }

        public ActionResult UnregisterToCourse(int courseId)
        {
            StudieDbEntities db = new StudieDbEntities();
            try
            {
                int userId = UserInfoController.GetUserId(User.Identity.Name);
                StudentsInCourse sIC = db.StudentsInCourse.Where(sic => sic.CourseId == courseId && sic.UserId == userId).FirstOrDefault();
                db.StudentsInCourse.Remove(sIC);
                db.SaveChanges();
                TempData["Message"] = "Du är inte längre registrerad till kursen";
            }
            catch (Exception e)
            {
                TempData["Message"] = "Något gick fel";
            }
            return RedirectToAction("ShowCourse", "MyCourses", new { courseId = courseId });
        }

        [HttpPost]
        public JsonResult CreateNewCourse(AllTeachers course)
        {
            Courses newCourse = new Courses()
            {
                Name = course.CourseName,
                Text = course.CourseText
            };
            StudieDbEntities db = new StudieDbEntities();
            int newCourseId = db.Courses.AsEnumerable().OrderByDescending(c => c.Id).Select(c => c.Id).FirstOrDefault() + 1;
            //int newCourseId = db.Courses.Max(c => c.Id) + 1;
            newCourse.Id = newCourseId;
            db.Courses.Add(newCourse);

            foreach (int teachId in course.TeachersAddedToCourse)
            {
                TeachersForCourse tfc = new TeachersForCourse() { CourseId = newCourse.Id, UserId = teachId };
                db.TeachersForCourse.Add(tfc);
            }

            if (course.ChoosenTasks != null)
            {
                for (int i = 0; i < course.ChoosenTasks.Length; i++)
                {
                    TaskInCourse tic = new TaskInCourse() { CourseId = newCourse.Id, OrderNumber = i, TaskId = course.ChoosenTasks[i] };
                    db.TaskInCourse.Add(tic);
                }
            }

            db.SaveChanges();
            return Json(new { success = true });
        }

        public AllTeachers GetTeachers()
        {
            StudieDbEntities db = new StudieDbEntities();
            int studentId = db.Roles.AsEnumerable().Where(r => r.Name == "Student").Select(r => r.Id).FirstOrDefault();
            AllTeachers allTeachers = new AllTeachers();
            Users[] teacherUsers = db.Users.Where(u => u.Role != studentId).ToArray();
            allTeachers.TeacherArray = new Teacher[teacherUsers.Length];
            int i = 0;

            foreach (Users user in teacherUsers)
            {
                allTeachers.TeacherArray[i] = new Teacher() { Id = user.Id, Username = user.Username };
                i++;
            }
            allTeachers.LoggedUserId = UserInfoController.GetUserId(User.Identity.Name);
            return allTeachers;
        }

        public ActionResult AddTaskToCourse()
        {
            return View();
        }

        public ActionResult ModifyCourse(int courseId)
        {
            CourseModel myCourse = GetCourse(courseId);
            myCourse.AllTeachers = GetTeachers();

            return View(myCourse);
        }

        public ActionResult ShowCourse(int courseId)
        {
            CourseModel myCourse = GetCourse(courseId);

            return View(myCourse);
        }

        public ActionResult AdminDeleteCourse(int courseId)
        {
            StudieDbEntities db = new StudieDbEntities();
            Courses course = db.Courses.Where(c => c.Id == courseId).FirstOrDefault();
            string courseName = course.Name;

            try {
                int[] teacherIds = db.TeachersForCourse.AsEnumerable().Where(tic => tic.CourseId == courseId).Select(tic => tic.UserId).ToArray();
                Courses deletCourse = db.Courses.Where(c => c.Id == courseId).FirstOrDefault();
                var tps = db.TaskPoints.Where(tp => tp.CourseId == courseId).ToArray();
                foreach (TaskPoints tp in tps)
                {
                    tp.CourseId = null;
                }
                var fts = db.FinishedTask.Where(ft => ft.CourseId == courseId).ToArray();
                foreach (FinishedTask ft in fts)
                {
                    ft.CourseId = null;
                }
                var fbgs = db.FeedBackGrades.Where(fbg => fbg.CourseId == courseId);
                foreach (FeedBackGrades fbg in fbgs)
                {
                    fbg.CourseId = null;
                }
                var comments = db.Comments.Where(c => c.CourseRef == courseId);
                foreach (Comments c in comments)
                {
                    c.CourseRef = null;
                }
                var tics = db.TaskInCourse.Where(tic => tic.CourseId == courseId);
                foreach (TaskInCourse tic in tics)
                {
                    db.TaskInCourse.Remove(tic);
                }

                db.Courses.Remove(course);
                db.SaveChanges();
                TempData["Message"] = "Kurs " + courseName + " har raderats";
                UserInfoController.SendMultipleEmail(teacherIds, "Kurs " + '"' + courseName + '"' + " som du varit delansvarig över har raderats av admin.", "Raderat inlägg");
            }
            catch(Exception e)
            {
                TempData["Message"] = e;
            }
                return RedirectToAction("MyCourses");
        }

        public ActionResult AdminAddToCourse(int courseId)
        {
            StudieDbEntities db = new StudieDbEntities();
            TeachersForCourse tic = new TeachersForCourse() { CourseId = courseId, UserId = UserInfoController.GetUserId(User.Identity.Name) };
            db.TeachersForCourse.Add(tic);
            int[] teacherIds = db.TeachersForCourse.AsEnumerable().Where(tic2 => tic2.CourseId == courseId).Select(tic2 => tic2.UserId).ToArray();
            Courses course = db.Courses.Where(c => c.Id == courseId).FirstOrDefault();
            string courseName = course.Name;
            db.SaveChanges();
            db.Dispose();

            TempData["Message"] = "Du är nu lärare i kurs " + courseName;
            UserInfoController.SendMultipleEmail(teacherIds, "Admin har gjort sig själv till delansvig av kurs " + '"' + courseName + '"' + " som du är delansvarig över.", "Admin övertag");
            return RedirectToAction("ShowCourse", "MyCourses", new { courseId = courseId });
        }

        public JsonResult SaveModifiedCourse(AllTeachers course)
        {
            StudieDbEntities db = new StudieDbEntities();
            Courses myCourse = db.Courses.Where(c => c.Id == course.CourseId).FirstOrDefault();
            myCourse.Name = course.CourseName;
            myCourse.Text = course.CourseText;

            var registredTeachers = db.TeachersForCourse.Where(tfc => tfc.CourseId == course.CourseId).ToList();
            foreach(var teacherConnection in registredTeachers)
            {
                db.TeachersForCourse.Remove(teacherConnection);
            }
            foreach(var teacherId in course.TeachersAddedToCourse)
            {
                TeachersForCourse newTeacher = new TeachersForCourse() { CourseId = course.CourseId, UserId = teacherId };
                db.TeachersForCourse.Add(newTeacher);
            }

            var registredTasks = db.TaskInCourse.Where(tic => tic.CourseId == course.CourseId).ToList();
            foreach(var taskConnection in registredTasks)
            {
                db.TaskInCourse.Remove(taskConnection);
            }
            int i = 1;
            foreach(var task in course.ChoosenTasks)
            {
                TaskInCourse newTask = new TaskInCourse() { CourseId = course.CourseId, OrderNumber = i, TaskId = task };
                db.TaskInCourse.Add(newTask);
                i++;
            }
            try
            {
                db.SaveChanges();
                TempData["Message"] = "Ändringar sparade";
                return Json(new { success = true });
            }
            catch
            {
                TempData["Message"] = "Något gick fel";
                return null;
            }
        }

        public CourseModel GetCourse(int courseId)
        {
            StudieDbEntities db = new StudieDbEntities();
            Courses course = db.Courses.FirstOrDefault(c => c.Id == courseId);
            CourseModel myCourse = new CourseModel() { Id = course.Id, Text = course.Text, Title = course.Name };

            myCourse.Students = new int[course.StudentsInCourse.Count];
            int i = 0;
            foreach (StudentsInCourse sic in course.StudentsInCourse)
            {
                myCourse.Students[i] = sic.UserId;
                i++;
            }

            int[] teacherIds = course.TeachersForCourse.AsEnumerable().Select(tfc => tfc.UserId).ToArray();
            myCourse.Teachers = db.Users.Where(u => teacherIds.Contains(u.Id)).ToArray();

            int userId = UserInfoController.GetUserId(User.Identity.Name);
            if (db.TeachersForCourse.Where(tfc => tfc.CourseId == myCourse.Id).Select(tfc => tfc.UserId).Contains(userId))
                myCourse.CourseOwner = true;

            myCourse.CourseTasks = GetCourseTasks(courseId);
            StudentsInCourse mySic = db.StudentsInCourse.FirstOrDefault(sic => sic.UserId == userId && sic.CourseId == courseId);
            if (mySic == null)
                myCourse.IsSubscribed = false;
            else
                myCourse.IsSubscribed = true;

            myCourse.IsAdmin = UserInfoController.IsAdmin(User.Identity.Name);

            return myCourse;
        }

        public ActionResult DeleteCourse(int courseId)
        {
            int userId = UserInfoController.GetUserId(User.Identity.Name);
            StudieDbEntities db = new StudieDbEntities();

            if (!db.TeachersForCourse.Where(tfc => tfc.CourseId == courseId).Select(tfc => tfc.UserId).Contains(userId))
            {
                TempData["Message"] = "Du har inte behörighet att radera den här kursen";
                return RedirectToAction("ShowCourse", "MyCourses", new { courseId = courseId });
            }
            else {
                try {
                    Courses deletCourse = db.Courses.Where(c => c.Id == courseId).FirstOrDefault();
                    var tps = db.TaskPoints.Where(tp => tp.CourseId == courseId).ToArray();
                    foreach(TaskPoints tp in tps)
                    {
                        tp.CourseId = null;
                    }
                    var fts = db.FinishedTask.Where(ft => ft.CourseId == courseId).ToArray();
                    foreach (FinishedTask ft in fts)
                    {
                        ft.CourseId = null;
                    }
                    var fbgs = db.FeedBackGrades.Where(fbg => fbg.CourseId == courseId);
                    foreach(FeedBackGrades fbg in fbgs)
                    {
                        fbg.CourseId = null;
                    }
                    var comments = db.Comments.Where(c => c.CourseRef == courseId);
                    foreach(Comments c in comments)
                    {
                        c.CourseRef = null;
                    }
                    var tics = db.TaskInCourse.Where(tic => tic.CourseId == courseId);
                    foreach (TaskInCourse tic in tics)
                    {
                        db.TaskInCourse.Remove(tic);
                    }

                    db.Courses.Remove(deletCourse);
                    db.SaveChanges();
                    TempData["Message"] = "Kurs raderad!";
                }
                catch(Exception e)
                {
                    TempData["Message"] = "Något gick fel";
                    return RedirectToAction("ShowCourse", "MyCourses", new { courseId = courseId });
                }
            }
            return RedirectToAction("MyCourses", "MyCourses");
        }

        public PreviewTaskArrayModel GetCourseTasks(int courseId)
        {
            PreviewTaskArrayModel prevTasks = new PreviewTaskArrayModel();
            using (StudieDbEntities db = new StudieDbEntities())
            {
                Tasks[] taskArray = db.TaskInCourse.Where(tic => tic.CourseId == courseId).Select(tic => tic.Tasks).ToArray();
                PreviewTaskModel[] myTasks = new PreviewTaskModel[taskArray.Length];

                int diffId = 0;
                int knownBeforeId = 0;
                int otherScale = 0;

                for (int i = 0; i < taskArray.Length; i++)
                {
                    myTasks[i] = new PreviewTaskModel();
                    myTasks[i].Id = taskArray[i].Id;
                    myTasks[i].Titel = taskArray[i].Title;
                    myTasks[i].Visningar = taskArray[i].Views;

                    myTasks[i].Writer = db.Users.AsEnumerable().Where(u => u.Id == taskArray[i].Writer).Select(u => u.Username).FirstOrDefault();

                    if (taskArray[i].Text.Length > 30)
                        myTasks[i].Text = taskArray[i].Text.Substring(0, 30) + "...";
                    else
                        myTasks[i].Text = taskArray[i].Text;
                    myTasks[i].AntalKlarade =
                        db.FinishedTask.AsEnumerable().Where(ft => ft.TaskId == myTasks[i].Id).ToArray().Length;

                    int[] tagsIdn = db.TagsInTask.AsEnumerable().Where(tit => tit.TaskId == myTasks[i].Id).Select(tit => tit.TagId).ToArray();
                    myTasks[i].Tags = db.Tags.AsEnumerable().Where(ta => tagsIdn.Contains(ta.Id)).Select(ta => ta.Namn).ToArray();

                    diffId =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id && f.Text == "1").Select(f => f.Id).FirstOrDefault();


                    knownBeforeId =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id && f.Text == "2").Select(f => f.Id).FirstOrDefault();

                    FeedbackScales fs =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id).FirstOrDefault(f => f.Text != "1" && f.Text != "2");
                    if (fs != null)
                    {
                        otherScale = fs.Id;
                        myTasks[i].OtherQuestionString = fs.Text;
                    }

                    myTasks[i].Difficulty = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == diffId).Select(fg => fg.Grade).ToArray();
                    myTasks[i].CouldBefore = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == knownBeforeId).Select(fg => fg.Grade).ToArray();
                    myTasks[i].OtherQuestion = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == otherScale).Select(fg => fg.Grade).ToArray();

                    myTasks[i].Comments = db.Comments.AsEnumerable().Where(c => c.TaskRef == myTasks[i].Id).ToArray();

                    myTasks[i].TummeUp = 0;
                    myTasks[i].TummeNer = 0;
                    bool[] points = db.TaskPoints.AsEnumerable().Where(tp => tp.TaskId == myTasks[i].Id).Select(tp => tp.Point).ToArray();
                    foreach (bool point in points)
                    {
                        if (point)
                        {
                            myTasks[i].TummeUp += 1;
                        }
                        else
                            myTasks[i].TummeNer += 1;
                    }

                    int taskId = myTasks[i].Id;
                    int userId = UserInfoController.GetUserId(User.Identity.Name);
                    FinishedTask inTask = db.FinishedTask.Where(ft => ft.TaskId == taskId && ft.UserId == userId).FirstOrDefault();
                    if (inTask != null)
                        myTasks[i].Finished = true;
                    else
                        myTasks[i].Finished = false;
                }
                prevTasks.PrevTasks = myTasks;
            }
            return prevTasks;

        }

        public ActionResult WatchStatistics(int courseId)
        {
            MyStudents students = new MyStudents() { CourseId = courseId };
            StudieDbEntities db = new StudieDbEntities();
            students.CourseName = db.Courses.AsEnumerable().Where(c => c.Id == courseId).Select(c => c.Name).FirstOrDefault();

            int[] tics = db.TaskInCourse.AsEnumerable().Where(tic => tic.CourseId == courseId).Select(tic => tic.TaskId).ToArray();
            Tasks[] tasks = db.Tasks.Where(t => tics.Contains(t.Id)).ToArray();

            int[] studentIds = db.StudentsInCourse.AsEnumerable().Where(sic => sic.CourseId == courseId).Select(sic => sic.UserId).ToArray();
            FeedBackGrades[] feedBackGrades = db.FeedBackGrades.AsEnumerable().Where(fbg => fbg.CourseId == courseId).ToArray();
            FinishedTask[] finishedTasks = db.FinishedTask.AsEnumerable().Where(ft => ft.CourseId == courseId).ToArray();
            TaskPoints[] taskPoints = db.TaskPoints.AsEnumerable().Where(tp => tp.CourseId == courseId).ToArray();

            StudentActivities[] stuAct = new StudentActivities[studentIds.Length];
            for (int i = 0; i < studentIds.Length; i++)
            {
                stuAct[i] = new StudentActivities() { UserId = studentIds[i] };
                List<TaskFeedback> taskFeedbacksForTask = new List<TaskFeedback>();
                foreach (Tasks task in tasks)
                {
                    //Tre möjliga feedback-typer: feedback-skala, tumme up/ner, avklarad
                    FinishedTask ft = finishedTasks.Where(ft2 => ft2.TaskId == task.Id && ft2.UserId == studentIds[i]).FirstOrDefault();
                    TaskPoints taskPoint = taskPoints.Where(tp => tp.TaskId == task.Id && tp.PointGiver == studentIds[i]).FirstOrDefault();
                    FeedBackGrades[] feedBack = feedBackGrades.Where(fbg => fbg.UserId == studentIds[i] && fbg.FeedbackScales.TaskRef == task.Id).ToArray();

                    if (ft != null || taskPoint != null || feedBack != null)
                    {
                        //Feedback-inlägg. All feedback från den här personen till den här uppgift inom den här kursen
                        TaskFeedback tfb = new TaskFeedback() { ThisTask = task };
                        if (ft != null)
                            tfb.MarkedAsDone = ft.DateFinished;
                        if (taskPoint != null)
                            tfb.Thumb = taskPoint.Point;
                        //feedback-skalor
                        if (feedBack != null)
                        {
                            foreach (FeedBackGrades fbg in feedBack)
                            {
                                if (fbg.FeedbackScales.Text == "1")
                                    tfb.Difficulty = fbg.Grade;
                                else if (fbg.FeedbackScales.Text == "2")
                                    tfb.CouldBefore = fbg.Grade;
                                else
                                {
                                    tfb.OtherGrade = fbg.FeedbackScales.Text;
                                    tfb.OtherGradePoint = fbg.Grade;
                                }
                                //Datum för feedback
                                tfb.DateForFeedBack = fbg.DateWritten;
                            }
                        }
                        if (taskPoint != null && tfb.DateForFeedBack == null)
                            tfb.DateForFeedBack = taskPoint.DateWritten;

                        if (tfb.MarkedAsDone != null || tfb.DateForFeedBack != null)
                            taskFeedbacksForTask.Add(tfb);
                    }
                }
                stuAct[i].TasksFeedback = taskFeedbacksForTask.ToArray();
                stuAct[i].TasksFeedback.OrderBy(tfb => tfb.DateForFeedBack);
            }
            students.StudentActivitiesArray = stuAct;



            Random rnd = new Random();
            students.StudentActivitiesArray.OrderBy(x => rnd.Next()).ToArray();

            return View(students);
        }
    }
}