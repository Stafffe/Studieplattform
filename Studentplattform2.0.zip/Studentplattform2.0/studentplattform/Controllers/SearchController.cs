﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Studentplattform.Models;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;

namespace Studentplattform.Controllers
{
    [Authorize]
    public class SearchController : Controller
    {
        // GET: Search
        public ActionResult Search()
        {
            return View();
        }

        [HttpPost]
        public String SearchCourses(String courseString)
        {
            StudieDbEntities db = new StudieDbEntities();
            Courses[] foundCourses = db.Courses.Where(c => c.Name.Contains(courseString)).ToArray();

            SearchResultModel[] sendCourses = new SearchResultModel[foundCourses.Length];
            for(int i = 0; i < foundCourses.Length; i++)
            {
                sendCourses[i] = new SearchResultModel() { Id=foundCourses[i].Id, Name = foundCourses[i].Name };
            }
            JavaScriptSerializer js = new JavaScriptSerializer();
            string resultString = js.Serialize(sendCourses);
            return resultString;
        }

        [HttpPost]
        public String SearchTags(String tagString)
        {
            StudieDbEntities db = new StudieDbEntities();
            Tags[] foundTags = db.Tags.AsEnumerable().Where(t => t.Namn.Contains(tagString)).ToArray();

            SearchResultModel[] sendTags = new SearchResultModel[foundTags.Length];
            for (int i = 0; i < foundTags.Length; i++)
            {
                sendTags[i] = new SearchResultModel() { Id = foundTags[i].Id, Name = foundTags[i].Namn };
            }
            JavaScriptSerializer js = new JavaScriptSerializer();
            string resultString = js.Serialize(sendTags);
            return resultString;
        }

        [HttpPost]
        public String SearchWriters(String writerString)
        {
            StudieDbEntities db = new StudieDbEntities();
            int studentId = db.Roles.AsEnumerable().Where(r => r.Name == "Student").Select(r => r.Id).First();
            Users[] foundWriters = db.Users.Where(u => u.Username.Contains(writerString) && u.Role != studentId).ToArray();

            SearchResultModel[] sendWriters = new SearchResultModel[foundWriters.Length];
            for (int i = 0; i < foundWriters.Length; i++)
            {
                sendWriters[i] = new SearchResultModel() { Id = foundWriters[i].Id, Name = foundWriters[i].Username };
            }
            JavaScriptSerializer js = new JavaScriptSerializer();
            string resultString = js.Serialize(sendWriters);
            return resultString;
        }

        [HttpPost]
        public String SearchTasksByTagg(string taggString)
        {
            StudieDbEntities db = new StudieDbEntities();
            int taggInt = db.Tags.AsEnumerable().Where(t => t.Namn == taggString).Select(t => t.Id).First();
            int[] taskIds = db.TagsInTask.AsEnumerable().Where(tit => tit.TagId == taggInt).Select(tit => tit.TaskId).ToArray();

            List<Tasks> tasks = db.Tasks.Where(t => taskIds.Contains(t.Id)).ToList();

            return CreateTaskArrayString(db, tasks);
        }

        [HttpPost]
        public string SearchTasksByWriter(String writerString)
        {
            List<Tasks> tasks = new List<Tasks>();
            StudieDbEntities db = new StudieDbEntities();

            int writerID = 0;
            if (writerString.Length == 0)
            {
                writerString = User.Identity.Name;
                writerID = UserInfoController.GetUserId(writerString);
            }
            else
            {
                writerID = db.Users.AsEnumerable().Where(u => u.Username == writerString).Select(u => u.Id).FirstOrDefault();
            }

            tasks = db.Tasks.AsEnumerable().Where(t => t.Writer == writerID).ToList();

            return CreateTaskArrayString(db, tasks);
        }

        [HttpPost]
        public String SearchTasksByTitle(String titleString)
        {
            List<Tasks> tasks = new List<Tasks>();
            StudieDbEntities db = new StudieDbEntities();
            tasks = db.Tasks.AsEnumerable().Where(t => t.Title.ToLower().Contains(titleString.ToLower())).ToList();

            return CreateTaskArrayString(db, tasks);
        }

        private String CreateTaskArrayString(StudieDbEntities db, List<Tasks> tasks)
        {
            PreviewTaskModel[] taskArray = new PreviewTaskModel[tasks.Count()];

            int i = 0;
            foreach (Tasks task in tasks)
            {
                var points = db.TaskPoints.AsEnumerable().Where(tp => tp.TaskId == task.Id).ToList();
                int tUp = 0;
                int tDown = 0;
                foreach (TaskPoints tp in points)
                {
                    if (tp.Point == true)
                        tUp += 1;
                    else
                        tDown += 1;
                }

                string author = db.Users.AsEnumerable().Where(u => u.Id == task.Writer).Select(u => u.Username).FirstOrDefault();

                int diffScaleId = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == task.Id && fs.Text == "1").Select(fs => fs.Id).FirstOrDefault();
                int[] diffPoints = db.FeedBackGrades.AsEnumerable().Where(fbg => fbg.FeedbackId == diffScaleId).Select(fbg => fbg.Grade).ToArray();
                int diffTot = 0;
                foreach (int point in diffPoints)
                {
                    diffTot += point;
                }
                int difficulty = 0;
                if (diffPoints.Length > 0)
                    difficulty = diffTot / diffPoints.Length;

                int comments = db.Comments.Where(c => c.TaskRef == task.Id).Count();

                int[] tagsIdn = db.TagsInTask.AsEnumerable().Where(tit => tit.TaskId == task.Id).Select(tit => tit.TagId).ToArray();
                String[] tags = db.Tags.AsEnumerable().Where(ta => tagsIdn.Contains(ta.Id)).Select(ta => ta.Namn).ToArray();
                String taggString = null;
                if (tags.Length > 0)
                {
                    taggString = tags[0];
                    for (int i2 = 1; i2 < tags.Length; i2++)
                    {
                        taggString += ", " + tags[i2];
                    }
                }

                taskArray[i] = new PreviewTaskModel();
                taskArray[i].Id = task.Id;
                taskArray[i].Titel = task.Title;
                taskArray[i].Visningar = task.Views;
                taskArray[i].TummeUp = tUp;
                taskArray[i].TummeNer = tDown;
                taskArray[i].Writer = author;
                taskArray[i].AntalKlarade = task.FinishedTask.Count();
                taskArray[i].DiffMed = difficulty;
                taskArray[i].NumberOfComments = comments;
                taskArray[i].TaggString = taggString;
                if (Regex.Replace(task.Text, @"<[^>]+>|&nbsp;", "").Trim().Length > 60)
                    taskArray[i].Text = Regex.Replace(task.Text, @"<[^>]+>|&nbsp;", "").Trim().Substring(0, 60) + "...";
                else
                    taskArray[i].Text = task.Text;

                int userId = UserInfoController.GetUserId(User.Identity.Name);
                FinishedTask inTask = db.FinishedTask.Where(ft => ft.TaskId == task.Id && ft.UserId == userId).FirstOrDefault();
                if (inTask != null)
                    taskArray[i].Finished = true;
                else
                    taskArray[i].Finished = false;
                i++;
            }

            JavaScriptSerializer js = new JavaScriptSerializer();
            return js.Serialize(taskArray);
        }

        public String SearchUsers(string seachString)
        {
            StudieDbEntities db = new StudieDbEntities();
            Users[] users = db.Users.AsEnumerable().Where(u => u.Username.ToLower().Contains(seachString.ToLower())).ToArray();

            AdminSearchResultModel[] results = new AdminSearchResultModel[users.Length];
            int i = 0;
            foreach (Users user in users)
            {
                AdminSearchResultModel oneResult = new AdminSearchResultModel() { Id = user.Id, Name = user.Username };
                if (user.Role == null)
                    oneResult.IsNotBanned = false;
                else
                    oneResult.IsNotBanned = true;
                results[i] = oneResult;
                i++;
            }

            JavaScriptSerializer js = new JavaScriptSerializer();
            string result = js.Serialize(results);
            return result;
        }

        public bool BanUser(int userId)
        {
            try
            {
                StudieDbEntities db = new StudieDbEntities();
                Users user = db.Users.Where(u => u.Id == userId).FirstOrDefault();
                user.Role = null;
                db.SaveChanges();
                UserInfoController.SendEmail(userId, "Ditt konto har blivit avstängt av admin.", "Avstängd");
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool UnBanUser(int userId)
        {
            try
            {
                StudieDbEntities db = new StudieDbEntities();
                Users user = db.Users.Where(u => u.Id == userId).FirstOrDefault();
                int teacherRoleId = db.Roles.Where(r => r.Name == "Teacher").Select(r => r.Id).FirstOrDefault();
                user.Role = teacherRoleId;
                db.SaveChanges();
                UserInfoController.SendEmail(userId, "Ditt konto har blivit återaktiverat av admin.", "Återaktiverat");
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool AdminChangeUsername(int userId, string newName)
        {
            StudieDbEntities db = new StudieDbEntities();
            Users user = db.Users.Where(u => u.Id == userId).FirstOrDefault();
            user.Username = newName;
            db.SaveChanges();
            UserInfoController.SendEmail(userId, "Ditt användarnamn har ändrats till " + '"' + newName + '"' + " av admin.", "Ändrat användarnamn");
            return true;
        }

    }
}