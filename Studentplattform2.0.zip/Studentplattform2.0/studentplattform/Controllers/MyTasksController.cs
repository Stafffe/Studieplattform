﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Studentplattform.Models;
using System.Text;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.Web.Mail;

namespace Studentplattform.Controllers
{
    [Authorize]
    public class MyTasksController : Controller
    {
        // GET: MyTasks
        public ActionResult MyTasks()
        {
            PreviewTaskArrayModel prevTasks = new PreviewTaskArrayModel();
            using (StudieDbEntities db = new StudieDbEntities())
            {
                int userId = UserInfoController.GetUserId(User.Identity.Name);
                Tasks[] taskArray = db.Tasks.Where(t => t.Writer == userId).ToArray();
                PreviewTaskModel[] myTasks = new PreviewTaskModel[taskArray.Length];

                int diffId = 0;
                int knownBeforeId = 0;
                int otherScale = 0;

                for (int i = 0; i < taskArray.Length; i++)
                {
                    myTasks[i] = new PreviewTaskModel();
                    myTasks[i].Id = taskArray[i].Id;
                    myTasks[i].Titel = taskArray[i].Title;
                    myTasks[i].Visningar = taskArray[i].Views;

                    myTasks[i].Writer = db.Users.AsEnumerable().Where(u => u.Id == taskArray[i].Writer).Select(u => u.Username).FirstOrDefault();

                    if (taskArray[i].Text.Length > 30)
                        myTasks[i].Text = taskArray[i].Text.Substring(0, 30) + "...";
                    else
                        myTasks[i].Text = taskArray[i].Text;
                    myTasks[i].AntalKlarade =
                        db.FinishedTask.AsEnumerable().Where(ft => ft.TaskId == myTasks[i].Id).ToArray().Length;

                    int[] tagsIdn = db.TagsInTask.AsEnumerable().Where(tit => tit.TaskId == myTasks[i].Id).Select(tit => tit.TagId).ToArray();
                    myTasks[i].Tags = db.Tags.AsEnumerable().Where(ta => tagsIdn.Contains(ta.Id)).Select(ta => ta.Namn).ToArray();

                    diffId =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id && f.Text == "1").Select(f => f.Id).FirstOrDefault();


                    knownBeforeId =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id && f.Text == "2").Select(f => f.Id).FirstOrDefault();

                    FeedbackScales fs =
                        db.FeedbackScales.AsEnumerable().Where(f => f.TaskRef == myTasks[i].Id).FirstOrDefault(f => f.Text != "1" && f.Text != "2");
                    if (fs != null)
                    {
                        otherScale = fs.Id;
                        myTasks[i].OtherQuestionString = fs.Text;
                    }

                    myTasks[i].Difficulty = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == diffId).Select(fg => fg.Grade).ToArray();
                    myTasks[i].CouldBefore = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == knownBeforeId).Select(fg => fg.Grade).ToArray();
                    myTasks[i].OtherQuestion = db.FeedBackGrades.AsEnumerable().Where(fg => fg.FeedbackId == otherScale).Select(fg => fg.Grade).ToArray();

                    myTasks[i].Comments = db.Comments.AsEnumerable().Where(c => c.TaskRef == myTasks[i].Id).ToArray();

                    myTasks[i].TummeUp = 0;
                    myTasks[i].TummeNer = 0;
                    bool[] points = db.TaskPoints.AsEnumerable().Where(tp => tp.TaskId == myTasks[i].Id).Select(tp => tp.Point).ToArray();
                    foreach (bool point in points)
                    {
                        if (point)
                        {
                            myTasks[i].TummeUp += 1;
                        }
                        else
                            myTasks[i].TummeNer += 1;
                    }
                }
                prevTasks.PrevTasks = myTasks;
            }
            return View(prevTasks);
        }

        [Authorize(Roles = "Teacher, Admin, OverAdmin")]
        public ActionResult NewTask()
        {
            return View();
        }

        [Authorize(Roles = "Teacher, Admin, OverAdmin")]
        public ActionResult CopyTask(int taskId)
        {
            StudieDbEntities db = new StudieDbEntities();
            Tasks task = db.Tasks.Where(t => t.Id == taskId).FirstOrDefault();
            CopyTask ct = new CopyTask() { Title = task.Title, Text = task.Text };
            return View("NewTask", ct);
        }

        public ActionResult IsTitleFree(string title)
        {
            Boolean isFree = true;
            StudieDbEntities db = new StudieDbEntities();
            if (db.Tasks.FirstOrDefault(t => t.Title == title) != null)
                isFree = false;

            return Json(new { success = true, free = isFree }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult SendFeedback(FeedbackModel feedback)
        {
            int userId = UserInfoController.GetUserId(User.Identity.Name);
            StudieDbEntities db = new StudieDbEntities();
            if (feedback.Comment != null)
            {
                Comments comment = new Comments
                {
                    Text = feedback.Comment,
                    Writer = userId,
                    TaskRef = feedback.TaskId,
                    CourseRef = feedback.CourseId,
                    DateWritten = System.DateTime.Now
            };
                db.Comments.Add(comment);
            }

            if (feedback.Thumb!= null)
            {
                TaskPoints tp = new TaskPoints
                {
                    Point = feedback.Thumb ?? default(bool),
                    PointGiver = userId,
                    TaskId = feedback.TaskId,
                    CourseId = feedback.CourseId,
                    DateWritten = System.DateTime.Now
            };
                db.TaskPoints.Add(tp);
            }

            if(feedback.Skala1 != 0)
            {
                int fbsId = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == feedback.TaskId).Where(fs => fs.Text == "1").Select(fs => fs.Id).FirstOrDefault();

                FeedBackGrades fbg = new FeedBackGrades { Grade = feedback.Skala1, UserId = userId, FeedbackId =  fbsId, CourseId = feedback.CourseId, DateWritten = System.DateTime.Now };

                db.FeedBackGrades.Add(fbg);
            }

            if (feedback.Skala2 != 0)
            {
                int fbsId = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == feedback.TaskId).Where(fs => fs.Text == "2").Select(fs => fs.Id).FirstOrDefault();

                FeedBackGrades fbg = new FeedBackGrades { Grade = feedback.Skala2, UserId = userId, FeedbackId = fbsId, CourseId = feedback.CourseId, DateWritten = System.DateTime.Now };

                db.FeedBackGrades.Add(fbg);
            }

            if (feedback.SkalaOther != 0)
            {
                int fbsId = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == feedback.TaskId).Where(fs => fs.Text != "1" && fs.Text != "2").Select(fs => fs.Id).FirstOrDefault();

                FeedBackGrades fbg = new FeedBackGrades { Grade = feedback.SkalaOther, UserId = userId, FeedbackId = fbsId, CourseId = feedback.CourseId, DateWritten = System.DateTime.Now };

                db.FeedBackGrades.Add(fbg);
            }

            try {
                    db.SaveChanges();
                    return Json(new { });
                }
                catch(Exception e)
                {
                    return null;
                }
        }

        [HttpPost]
        [Authorize(Roles = "Teacher, Admin, OverAdmin")]
        public ActionResult NewTaskCreate(Task newTask)
        {
            Boolean done = false;
            String successMessage;
            using (StudieDbEntities dbEnt = new StudieDbEntities())
            {
                var dbTask = dbEnt.Tasks.Create();
                Tasks taskOnly = new Tasks()
                {
                    Writer = UserInfoController.GetUserId(User.Identity.Name),
                    Title = newTask.Title,
                    Text = newTask.Text
                };
                if (newTask.Image != null)
                {
                    try
                    {
                        taskOnly.Image = Encoding.Unicode.GetBytes(newTask.Image);
                    }
                    catch (Exception e) { }
                }

                //Uppgift in i databasen
                dbTask = taskOnly;
                dbEnt.Tasks.Add(dbTask);
                try
                {
                    dbEnt.SaveChanges();
                    successMessage = "Uppgift skapad!";
                    done = true;
                }
                catch (Exception e)
                {
                    return null;
                }

                //TAGGAR
                if (newTask.Tags != null)
                {
                    Tags[] tagArray = new Tags[newTask.Tags.Length];
                    int i = 0;
                    foreach (String tagName in newTask.Tags)
                    {
                        Tags newTag = new Tags() { Namn = tagName };
                        tagArray[i] = newTag;
                        i++;
                    }
                    i = 0;
                    foreach (Tags aktTag in tagArray)
                    {
                        try
                        {
                            tagArray[i] = dbEnt.Tags.First(tag => tag.Namn == aktTag.Namn);

                        }
                        catch (Exception e) { }
                        if (tagArray[i].Id == 0)
                        {
                            try
                            {
                                dbEnt.Tags.Add(aktTag);
                                dbEnt.SaveChanges();
                            }
                            catch (Exception e)
                            {
                                successMessage = "Uppgift skapad, men viss data gick förlorad";
                                done = false;
                            }
                        }
                        TagsInTask tit = new TagsInTask() { TagId = tagArray[i].Id, TaskId = dbTask.Id };
                        dbEnt.TagsInTask.Add(tit);

                        i++;
                    }

                    try
                    {
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }

                //TIPS
                if (newTask.Tips != null)
                {
                    try
                    {
                        Tips tip = new Tips { TipsText = newTask.Tips, TaskId = dbTask.Id };
                        dbEnt.Tips.Add(tip);
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }

                //SVAR
                if (newTask.Answer != null)
                {
                    try
                    {
                        Svar answer = new Svar() { SvarText = newTask.Answer, TaskId = dbTask.Id };
                        dbEnt.Svar.Add(answer);
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }

                //SVARALTERNATIV
                if (newTask.AnswerOptions != null)
                {
                    for (int i = 0; i < newTask.AnswerOptions.Length; i++)
                    {
                        answerOptions opt = new answerOptions { optionText = newTask.AnswerOptions[i] };
                        if (newTask.CorrectAnswer[i] == "True")
                            opt.isCorrect = true;
                        else
                            opt.isCorrect = false;
                        opt.TaskId = dbTask.Id;
                        dbEnt.answerOptions.Add(opt);
                    }
                    try
                    {
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }

                //SVARALTERNATIVSTRING
                if (newTask.TextOption != null)
                {
                    answerOptionText txtOpt = new answerOptionText { svarString = newTask.TextOption, TaskId = dbTask.Id };
                    try
                    {
                        dbEnt.answerOptionText.Add(txtOpt);
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }

                //FEEDBACK
                if (newTask.FeedbackScale != null)
                {
                    FeedbackScales feScale = new FeedbackScales();
                    String[] feScaleText = newTask.FeedbackScale.ToArray();
                    feScale.Text = feScaleText[0];
                    feScale.TextOne = feScaleText[1];
                    feScale.TextFour = feScaleText[2];
                    feScale.TaskRef = dbTask.Id;
                    try
                    {
                        dbEnt.FeedbackScales.Add(feScale);
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }
                for (int i = 1; i < 3; i++) {
                    try
                    {
                        FeedbackScales feScale = new FeedbackScales() { Text = i.ToString(), TaskRef = dbTask.Id};
                        dbEnt.FeedbackScales.Add(feScale);
                        dbEnt.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        successMessage = "Uppgift skapad, men viss data gick förlorad";
                        done = false;
                    }
                }
            }
            return Json(new { success = true, finished = done, message = successMessage }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SearchTags(string term)
        {
            TaggModel tm = new TaggModel();
            return Json(tm.Search(term), JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteTask(string taskName)
        {
            try
            {
                StudieDbEntities db = new StudieDbEntities();
                db.Tasks.Remove(db.Tasks.FirstOrDefault(t => t.Title == taskName));
                db.SaveChanges();
                return Json(new { success = "true" });
            }
            catch (Exception e)
            {
                return Json(new { success = "false" });
            }
        }


        public ActionResult TaskInfo()
        {
            return View();
        }

        [Authorize(Roles = "Teacher, Admin, OverAdmin")]
        public ActionResult ModifyTask()
        {
            return View();
        }

        public ActionResult ViewTask2(PreviewTaskArrayModel taskArray)
        {
            return RedirectToAction("ViewTask", new { taskId = taskArray.TaskId } );
        }

        public void AddView(int taskId)
        {
            var db = new StudieDbEntities();

            Tasks taskUpdate = db.Tasks.FirstOrDefault(t => t.Id == taskId);
            taskUpdate.Views += 1;
            db.SaveChanges();
        }

        public ActionResult ViewTaskFromCourse(int taskId, int courseId)
        {
            AddView(taskId);
            Task myTask = GetTask(taskId);
            myTask.CourseId = courseId;
            return View("ViewTask", myTask);
        }

        public ActionResult ViewTask(int taskId)
        {
            AddView(taskId);
            return View(GetTask(taskId));
        }

        public Task GetTask(int id)
        {
            Task task = new Task();
            var db = new StudieDbEntities();
            Tasks taskDb = db.Tasks.FirstOrDefault(t => t.Id == id);

            task.Id = taskDb.Id;
            task.Title = taskDb.Title;
            task.AntalVisningar = taskDb.Views;
            task.Text = taskDb.Text;
            if (taskDb.Image != null)
            {
                task.Image = Encoding.Unicode.GetString(taskDb.Image);
            }

            task.AnswerOptionsArray = db.answerOptions.Where(ao => ao.TaskId == id).ToArray();
            task.TextOption = db.answerOptionText.AsEnumerable().Where(aot => aot.TaskId == id).Select(aot => aot.svarString).FirstOrDefault();
            task.FeedbackScaleEnt = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == id).ToArray();
            task.Tips = db.Tips.AsEnumerable().Where(t => t.TaskId == id).Select(t => t.TipsText).FirstOrDefault();
            task.Answer = db.Svar.AsEnumerable().Where(a => a.TaskId == id).Select(a => a.SvarText).FirstOrDefault();
            task.Writer = db.Users.AsEnumerable().Where(u => u.Id == taskDb.Writer).Select(u => u.Username).FirstOrDefault();
            task.AntalKlarade = db.FinishedTask.AsEnumerable().Where(ft => ft.TaskId == id).ToArray().Length;
            task.Tummar = db.TaskPoints.AsEnumerable().Where(tp => tp.TaskId == id).Select(tf => tf.Point).ToArray();
            var Comments = db.Comments.AsEnumerable().Where(c => c.TaskRef == id).ToArray();
            task.Comments = new Comment[Comments.Length];
            for (int x = 0; x < Comments.Length; x++)
            {
                task.Comments[x] = new Comment();
                task.Comments[x].Text = Comments[x].Text;
                task.Comments[x].WriterName = db.Users.AsEnumerable().Where(u => u.Id == Comments[x].Writer).Select(u => u.Username).FirstOrDefault();
            }


            int userId = UserInfoController.GetUserId(User.Identity.Name);
            if (taskDb.Writer == userId)
            {
                task.IsWriter = true;
                task.CanLeaveFeedback = false;
                task.CanMarkAsFinished = false;
            }
            else
            {
                task.IsWriter = false;
                if (db.FinishedTask.Where(ft => ft.TaskId == taskDb.Id).FirstOrDefault(ft => ft.UserId == userId) != null)
                {

                    task.CanMarkAsFinished = false;
                }
                else
                {
                    task.CanMarkAsFinished = true;
                }

                if (db.Comments.Where(c => c.TaskRef == task.Id).FirstOrDefault(c => c.Writer == userId) != null)
                {
                    task.CanLeaveFeedback = false;
                }
                else if (db.TaskPoints.Where(tp => tp.TaskId == task.Id).FirstOrDefault(tp => tp.PointGiver == userId) != null)
                {
                    task.CanLeaveFeedback = false;
                }
                else {
                    task.CanLeaveFeedback = true;
                    int[] feedbackIds = db.FeedbackScales.AsEnumerable().Where(fs => fs.TaskRef == task.Id).Select(fs => fs.Id).ToArray();
                    foreach(int fbId in feedbackIds)
                    {
                        if(db.FeedBackGrades.Where(fbg => fbg.FeedbackId == fbId).FirstOrDefault(fbg => fbg.UserId == userId) != null)
                        {
                            task.CanLeaveFeedback = false;
                        }
                    }
                }
            }
            task.IsAdmin = UserInfoController.IsAdmin(User.Identity.Name);

            return task;
        }

        public ActionResult AdminDeleteTask(int taskId)
        {
            if (UserInfoController.IsAdmin(User.Identity.Name))
            {
                StudieDbEntities db = new StudieDbEntities();
                Tasks task = db.Tasks.FirstOrDefault(t => t.Id == taskId);
                string taskName = task.Title;
                int userId = task.Writer;
                db.Tasks.Remove(task);
                db.SaveChanges();
                TempData["Message"] = "Uppgift " + taskName + " raderad";

                UserInfoController.SendEmail(userId, "Din uppgift " + '"' + taskName + '"' + " på Studieplattformen.se har raderats av en admin.", "Raderat inlägg");

                return RedirectToAction("MyTasks");
            }
            else
                return null;
        }

        public ActionResult MarkFinished(Task task)
        { 
            StudieDbEntities db = new StudieDbEntities();
            FinishedTask ft = new FinishedTask() { TaskId = task.Id, CourseId = task.CourseId, UserId = UserInfoController.GetUserId(User.Identity.Name), DateFinished = System.DateTime.Now };
            db.FinishedTask.Add(ft);
            Tasks taskUpdate = db.Tasks.FirstOrDefault(t => t.Id == task.Id);
            taskUpdate.Views -= 1;
            db.SaveChanges();
            TempData["Message"] = "Uppgift markerad som avklarad!";
            if (task.CourseId == null)
                return RedirectToAction("ViewTask", new PreviewTaskArrayModel { TaskId = task.Id });
            else
                return RedirectToAction("ViewTaskFromCourse", new { TaskId = task.Id, courseId = task.CourseId });
        }


    }
}