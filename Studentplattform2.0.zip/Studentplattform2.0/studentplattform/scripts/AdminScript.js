﻿window.addEventListener('load', loadedFunction);
function loadedFunction() {
    var resultOptions = $("#adminSearchedUsers");

    $("#adminSearchBtn").click(function () {
        search();
    });

    function search() {
        var search = $("#adminSearch").val()
        $.ajax({
            url: '/Search/SearchUsers',
            type: 'POST',
            data: { 'seachString': search },
            success: function (result) {
                var adminSearchJson = JSON.parse(result);
                resultOptions.html("");
                for (i = 0; i < adminSearchJson.length; i++) {
                    if (adminSearchJson[i].IsNotBanned)
                        resultOptions.append("<option value='" + adminSearchJson[i].Id + "'>" + adminSearchJson[i].Name + "</option>");
                    else
                        resultOptions.append("<option class='banned' value='" + adminSearchJson[i].Id + "'>" + adminSearchJson[i].Name + "</option>");
                }
                editAdminButton();
            },
            error: function (err) {
                alert("Något gick fel");
            }
        });
    };

    resultOptions.change(function () {
        editAdminButton();
    });

    function editAdminButton() {
        if ($("#adminSearchedUsers option:selected").hasClass("banned")) {
            $("#BanUserBtn").val("Återaktivera användare");
            $("#BanUserBtn").removeClass("ban");
            $("#BanUserBtn").addClass("unban");
        }
        else {
            $("#BanUserBtn").val("Stäng av användare");
            $("#BanUserBtn").removeClass("unban");
            $("#BanUserBtn").addClass("ban");
        }
    };

    $("#changeUserName").click(function () {
        var searchVal = $("#adminSearchedUsers").val();
        if (searchVal == null) {
            Messenger().post("Du måste välja en användare");
            return;
        }

        var newName = $("#newUserName").val();
        if (newName.length == 0) {
            Messenger().post("Du måste ange ett nytt användarnamn");
            return;
        }

        $.ajax({
            url: '/Search/AdminChangeUsername',
            type: 'POST',
            data: { 'userId': searchVal, 'newName': newName },
            success: function (result) {
                $("#adminSearchedUsers option:selected").text(newName);
                Messenger().post("Användarnamnet ändrat till " + newName);
            },
            error: function (err) {
                Messenger().post("Något gick fel, prova ett annat användarnamn");
            }
        });
    });

    $("#BanUserBtn").click(function () {
        var searchVal = $("#adminSearchedUsers").val();
        if (searchVal == null) {
            Messenger().post("Du måste välja en användare");
            return;
        }

        var knapp = $("#BanUserBtn");
        knapp.removeAttr("id");
        if (knapp.hasClass("ban")) {
            $.ajax({
                url: '/Search/BanUser',
                type: 'POST',
                data: { 'userId': searchVal },
                success: function (result) {
                    $("#adminSearchedUsers option:selected").addClass("banned");
                    editAdminButton();
                    Messenger().post("Användare avstängd");
                },
                error: function () {
                    Messenger().post("Något gick fel");
                }
            });
        }
        else {
            $.ajax({
                url: '/Search/UnBanUser',
                type: 'POST',
                data: { 'userId': searchVal },
                success: function (result) {
                    $("#adminSearchedUsers option:selected").removeClass("banned");
                    editAdminButton();
                    Messenger().post("Användare återaktiverad");
                },
                error: function () {
                    Messenger().post("Något gick fel");
                }
            });
        }
        knapp.attr("id", "BanUserBtn");
    });

};