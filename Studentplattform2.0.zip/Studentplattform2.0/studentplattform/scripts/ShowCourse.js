﻿window.addEventListener('load', loadFunction);
function loadFunction() {
    var taskItemShowMore = $(".taskItem");
    taskItemShowMore.each(function () {
        if (!$(this).hasClass("haveShowMore")) {
            //var data = CKEDITOR.instances.editor2.getData();
            $(this).click(function () {
                if ($(this).next().is(":hidden")) {
                    $(this).next().slideDown("slow");
                    $(this).find('.plus').attr("src", "/Images/Less.png");
                } else {
                    $(this).next().slideUp("slow");
                    $(this).find(".plus").attr("src", "/Images/More.png")
                }
                $(this).addClass("haveShowMore");
            })
        }
    });
};