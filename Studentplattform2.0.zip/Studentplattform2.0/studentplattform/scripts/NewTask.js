﻿window.addEventListener('load', loadFunction);
function loadFunction() {
    //Klick på "Lägg till uppgifdel"-div
    $(".taskItem").click(function () {
        //var data = CKEDITOR.instances.editor2.getData();
        var pressed = $(this);
        if ($(this).next().is(":hidden")) {
            $(this).next().slideDown("slow");
            $(this).children().first().attr("src", "/Images/Less.png");
        } else {
            $(this).next().slideUp("slow");
            $(this).children().first().attr("src", "/Images/More.png")
            if (taskItemValidation($(this).attr('id'))) {
                $(this).addClass('taskItemGreen');
            }
            else {
                $(this).removeClass('taskItemGreen')
                $(this).next().slideUp("slow");
                $(this).children().first().attr("src", "/Images/More.png");
            }
        }
    });


    //Lägg-till-knapp upgiftsdel
    var taskItems = document.getElementsByClassName("addTaskItem");
    for (var i = 0; i < taskItems.length; i++) {
        taskItems[i].onclick = function () {
            if (taskItemValidation($(this).parent().prev().attr('id'))) {
                $(this).parent().prev().addClass('taskItemGreen');
                $(this).parent().slideUp("slow");
                $($(this).parent().prev().children().first().attr("src", "/Images/More.png"));
            }
            else {
                alert("Du har inte fyllt i tillräckligt mycket för att spara denna del!");
            }
        }
    }

    //Ta bort uppgiftsdel
    var taskRemove = document.getElementsByClassName("removeTaskItem");
    for (var i = 0; i < taskRemove.length; i++) {
        taskRemove[i].onclick = function () {
            taskItemClear($(this).parent().prev().attr('id'));
            $(this).parent().slideUp("slow");
            $(this).parent().prev().removeClass('taskItemGreen');
            $($(this).parent().prev().children().first().attr("src", "/Images/More.png"));
        }
    }

    //Töm uppgiftsdel
    function taskItemClear(taskId) {
        switch (taskId) {
            case "taskItem1":
                CKEDITOR.instances.editor2.setData('');
            case "taskItem2": {
                CKEDITOR.instances.editor3.setData('');
            }
            case "taskItem3": {
                break;
            }
            case "taskItem4": {
                break;
            }
        }
    }


    //validera, är upgiftsdelen ifylld ordentligt?
    function taskItemValidation(taskId) {
        switch (taskId) {
            case "taskItem1": {
                if (CKEDITOR.instances.editor2.getData().length > 0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            case "taskItem2": {
                if (CKEDITOR.instances.editor3.getData().length > 0) {
                    return true;
                }
                else {
                    return false;
                }
            }
            case "taskItem3": {
                var isValid = true;
                if ($("#optionsRadio1").prop("checked")) {
                    var options = $(".optionText");
                    for (i = 0; i < options.length; i++) {
                        if (options.eq(i).val().length == 0) {
                            var isValid = false;
                        }
                    }
                    var checkboxes = $(".correctCheck");
                    if (isValid) {
                        isValid = false;
                        for (i = 0; i < checkboxes.length; i++) {
                            if (checkboxes.eq(i).prop("checked")) {
                                isValid = true;
                                break;
                            }
                        }
                    }
                }
                else {
                    if ($("#optionsRadio2").prop("checked")) {
                        if ($("#maxLetterText").val().length != $("#1-20").val())
                            return false;
                    }
                }
                return isValid;
            }
            case "taskItem4": {
                if ($("#question").val().length == 0 || $("#question").val().length > 50)
                    return false;
                if ($("#1question").val().length == 0 || $("#1question").val().length > 20)
                    return false;
                if ($("#4question").val().length == 0 || $("#4question").val().length > 20)
                    return false;
                return true;
            }
        }
    }

    function imageCanvasValidation(imageCan) {
        var blank = document.createElement('canvas');
        blank.width = imageCan.width;
        blank.height = imageCan.height;

        if (imageCan.toDataURL() == blank.toDataURL())
            return false;
        return true;
    }


    //Svarsalternativ -> Antal alternativ -> nummerlista ändrad
    var optionScroll = document.getElementById("answerOptionsScroll");
    if (optionScroll != null) {
        optionScroll.onchange = function () {
            var intOption = optionScroll.options[optionScroll.selectedIndex].value;
            var optionsDiv = document.getElementById("options");
            text = '<div id="answerColorBg">';
            text += '<input type="text" class="optionText" /><label class="checkbox" for="searchCheckbox1"><input type="checkbox" value="" id="searchCheckbox1" data-toggle="checkbox" class="custom-checkbox correctCheck"><span class="icons"><span class="icon-unchecked"></span><span class="icon-checked"></span></span></label>'
            for (var i = 2; i <= Number(intOption) ; i++) {
                text += '<br><input type="text" class="optionText" /><label class="checkbox" for="searchCheckbox' + i + '"><input type="checkbox" value="" id="searchCheckbox' + i + '" data-toggle="checkbox" class="custom-checkbox correctCheck"><span class="icons"><span class="icon-unchecked"></span><span class="icon-checked"></span></span></label>';
                if ((intOption / 2) == (i - 1) || (intOption / 2) == (i - 0.5)) {
                    text += '<span style="padding-left:20px" />Markera rätt svar';
                }
            }
            text.innerHTML += '</div>';
            optionsDiv.innerHTML = text;
        };
    }

    //Svarsalternativ -> Antal alternativ/Antal bokstäver?
    document.getElementById('optionsRadio1').onclick = function () {
        $('#answerLetters').hide();
        $('#answerOptions').slideDown("slow");
    }
    document.getElementById('optionsRadio2').onclick = function () {
        $('#answerOptions').hide();
        $('#answerLetters').slideDown("slow");
    }

    //fyll antal-bokstäver-droplista
    $(function () {
        var $select = $("#1-20");
        for (i = 1; i <= 20; i++) {
            $select.append($('<option></option>').val(i).html(i))
        }
    });

    //max bokstäver, svarsalternativ
    document.getElementById('1-20').onchange = function () {
        $('#maxLetterText').val('');
        $('#maxLetterText').attr('maxlength', $('#1-20').val());
    }

    function clearErrors() {
        $("#title Error").text("");
        $("#textError").text("");
    }




    $("#addImage").change(function () {
        if (isImage(document.querySelector('input[type=file]').files[0])) {
            var canvas = document.getElementById('preview');
            var context = canvas.getContext('2d');
            var reader = new FileReader();
            reader.onload = function (event) {
                var img = new Image();
                img.onload = function () {
                    canvas.width = img.width;
                    canvas.height = img.height;
                    context.drawImage(img, 0, 0);
                }
                img.src = event.target.result;
            }
            reader.readAsDataURL(document.querySelector('input[type=file]').files[0]);
        }
    });

    function isImage(file) {
        var fileType = file["type"];
        var ValidImageTypes = ["image/gif", "image/jpeg", "image/png"];
        if ($.inArray(fileType, ValidImageTypes) < 0) {
            return false;
        }
        else
            return true;
    }




    //Skapa uppgift
    $("#submitTask").on('click', function () {
        document.body.scrollTop = document.documentElement.scrollTop = 0;
        clearErrors();
        var obj = {};
        if ($("#title").val().length == 0) {
            $("#titleError").text("Du måste ange en titel");
            return;
        }
        if ($("#title").val().length > 20) {
            $("#titleError").text("Titeln får vara max 20bokstäver långt");
            return;
        }
        obj.Title = $("#title").val();
        if (CKEDITOR.instances.editor1.getData().length == 0) {
            $("#textError").text("Du måste skriva in uppgiftstexten");
            return;
        }
        if (CKEDITOR.instances.editor1.getData().length > 3000) {
            $("#textError").text("Uppgiftstextens källkod får vara max 3000 tecken långt");
            return;
        }

        obj.Text = CKEDITOR.instances.editor1.getData();

        if (imageCanvasValidation(document.getElementById("preview")))
            obj.Image = document.getElementById("preview").toDataURL();


        if (taskItemValidation("taskItem1")) {
            obj.Tips = CKEDITOR.instances.editor2.getData();
        }

        if (taskItemValidation("taskItem2"))
            obj.Answer = CKEDITOR.instances.editor3.getData();

        if (taskItemValidation("taskItem3")) {
            if ($("#optionsRadio1").prop("checked")) {
                var options = $(".optionText");
                var optionArray = [];
                for (i = 0; i < options.length; i++) {
                    optionArray.push(options.eq(i).val());
                }
                var optionCorrect = [];
                var checkboxes = $(".correctCheck");
                var checkedBoxes = [];
                for (i = 0; i < checkboxes.length; i++) {
                    if (checkboxes.eq(i).prop("checked")) {
                        checkedBoxes[i] = true;
                    }
                    else {
                        checkedBoxes[i] = false;
                    }
                }

                obj.AnswerOptions = optionArray;
                obj.CorrectAnswer = checkedBoxes;
            }
            else if ($("#optionsRadio2").prop("checked")) {
                obj.TextOption = $("#maxLetterText").val();
            }
        }



        if (taskItemValidation("taskItem4")) {
            var Scale = [];
            Scale.push($("#question").val());
            Scale.push($("#1question").val());
            Scale.push($("#4question").val());
            obj.FeedbackScale = Scale;
        }

        var tags = [];
        for (i = 0; i < $(".tag").length; i++) {
            tags.push($(".tag").eq(i).text());
        }
        obj.Tags = tags;

        $.ajax({
            url: 'NewTaskCreate',
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(obj),
            success: function (result) {
                if (result.success == true) {
                    Messenger().post(result.message);
                    clearAll();
                }
            },
            error: function (err) {
                Messenger().post("Något gick fel, pröva med en mindre bild");
            }
        });

    });


    //Inte färdig, töm svarsalternativ+feedback kvar
    function clearAll(){
        $("#title").val("");
        CKEDITOR.instances.editor1.setData("");
        CKEDITOR.instances.editor2.setData("");
        CKEDITOR.instances.editor3.setData("");
        var canvas = document.getElementById('preview');
        var context = canvas.getContext('2d');
        context.clearRect(0, 0, canvas.width, canvas.height);
        
        $("#maxLetterText").val("");

        $(".optionText").each(function () {
            $(this).val("");
        });

        $("#question").val("");
        $("#1question").val("");
        $("#4question").val("");

        $(".tag").each(function () {
            this.remove();
        });

        $(".taskItemGreen").each(function () {
            $(this).removeClass("taskItemGreen");
        });
    }



    $("#title").change(function () {
        isTitleFree();
    });

    function isTitleFree() {
        var title = $("#title").val();

        $.ajax({
            url: 'IsTitleFree',
            type: 'POST',
            data: { 'title': title },
            success: function (result) {
                if (result.success == true) {
                    if (result.free == false) {
                        $("#titleError").text("Titeln är upptagen!");
                        return false;
                    }
                    else {
                        $("#titleError").text("");
                        return true;
                    }
                }
            },
            error: function (err) {
                Messenger().post("Problem med databasen");
                $("#titleError").text("");
                return true;
            }
        });
    }

    $(document).on('click', ".tag", function () {
        $(this).remove();
    });

    $("#addTag").click(function () {
        var tagName = $("#newTag").val();
        var tagArray = [];
        for (i = 0; i < $('.tag').length; i++){
            tagArray[i] = $('.tag').eq(i).text();
        };
        if (tagName.length > 0) {
            if (tagName.length < 20) {
                if ($(".tag").length < 6) {
                    if ($.inArray(tagName, tagArray) == -1) {
                        $("#taggar").append('<span class="tag label label-info">' + tagName + '<span data-role="remove"></span></span>');
                        $("#tagError").text("");
                    }
                    else{
                        $("#tagError").text("Taggen är redan tillagd");
                    }
                }
                else {
                    $("#tagError").text("Din uppgift kan ha max 6taggar");
                }
            }
            else {
                $("#tagError").text("Taggen måste vara mindre än 20 tecken långt");
            }
        }
        else{
            $("#tagError").text("Taggen måste vara mer än 1 tecken långt");
        }
    });
}