﻿window.addEventListener('load', loadFunction);
function loadFunction() {
    for (i = 0; i < $(".deleteButton").length; i++) {
        $(".deleteButton").eq(i).click(function () {

            var taskBody = $(this).parent();
            var taskheader = taskBody.prev();

            var task = taskheader.find(".titleDiv").text();
            if (window.confirm("Är du säker att du vill radera " + task + "?")) {

                $.ajax({
                    type: "POST",
                    contentType: "application/json; charset=utf-8",
                    url: "DeleteTask",
                    data: JSON.stringify({ "taskName": task }),
                    dataType: "json",
                    success: function (result) {
                        if (result.success == "true") {
                            Messenger().post('Uppgift raderad');
                            taskBody.remove();
                            taskheader.remove();
                        }
                        else {
                            Messenger().post('Något gick fel, kunde inte radera');
                        }
                    },
                    error: function (result) {
                        alert('Något gick fel, kunde inte radera');
                    }
                });

            }
        });
    }
}