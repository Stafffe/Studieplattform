﻿window.addEventListener('load', loadFunction);

function loadFunction() {

    window.onscroll = function () {
        if (document.body.scrollTop > 80) {
            var elem = document.querySelector("#menuButtons");
            if (elem != null) {
                elem.classList.add("fixed");
                elem.removeAttribute("id");
                $("#menuButtonPlaceHolder").attr("class", "PlaceHolder");
            }
        }
        else if (document.body.scrollTop < 80) {
            var elem = document.querySelector(".fixed");
            if (elem != null) {
                $("#menuButtonPlaceHolder").attr("class", "");
                elem.id = "menuButtons";
                elem.classList.remove("fixed");
            }
        }
    }

    //footer längst ner
    //if (document.body.scrollHeight < (screen.height - 50)) {
    //    var footer = document.getElementById("footer");
    //    footer.style.position = "fixed";
    //    footer.style.width = "calc(70% - 40px)";
    //    footer.style.marginRight = "15%";

    //    document.getElementById("main").style.height = "85vh";
    //}



    var str = location.href.toLowerCase();
    buttons = $('.menuButton');
    for (i = 0; i < buttons.length; i++) {
        if (str.indexOf(buttons.get(i).href.toLowerCase()) > -1) {
            $(buttons.get(i)).removeClass("currentButton");
            $(buttons.get(i)).addClass("currentButton");
        }
    }
    
    Messenger.options = {
        extraClasses: 'messenger-fixed messenger-on-bottom messenger-on-right',
        theme: 'flat',
    }

}






