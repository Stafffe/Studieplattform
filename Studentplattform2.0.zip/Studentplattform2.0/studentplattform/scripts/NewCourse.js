﻿window.addEventListener('load', loadFunction);
function loadFunction() {
    $("#addOwner").click(function () {
        var teacherOpt = $("#canAdd option:selected");
        if (teacherOpt.text().length > 0) {
            teacherOpt.remove();
            $("#added").append(teacherOpt[0].outerHTML);
        }
    });

    $("#removeOwner").click(function () {
        var teacherOpt = $("#added option:selected");
        if (teacherOpt.attr("id") == "loggedUser") {
            Messenger().post("Du kan inte ta bort dig själv!");
            return;
        }
        if (teacherOpt.text().length > 0) {
            teacherOpt.remove();
            $("#canAdd").append(teacherOpt[0].outerHTML);
        }
    });

    $("#publish").click(function () {
        var obj = {};
        if (!titleValid()) {
            Messenger().post("Titeln är ej godkänd");
            return;
        }

        obj.CourseName = $("#courseTitle").val();

        obj.CourseText = CKEDITOR.instances.editor1.getData();


        if (obj.CourseText.length > 3000) {
            $("#textError").text("Kursmeddelandets källkod får vara max 3000 tecken långt");
            Messenger().post("Kursmeddelande ej godkänt");
            return;
        }

        var teachersIds = $("#added").find(".courseTeachers");
        var tIds = [];
        for (i = 0; i < teachersIds.length; i++) {
            tIds.push(teachersIds.eq(i).val());
        }
        obj.TeachersAddedToCourse = tIds;

        var tasksIds = $("#addedTasks").find(".fullTask");
        var taskIds = [];
        for (i = 0; i < tasksIds.length; i++) {
            taskIds.push(tasksIds.eq(i).attr("id"));
        }
        obj.ChoosenTasks = taskIds;


        $.ajax({
            url: 'CreateNewCourse',
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(obj),
            success: function (result) {
                if (result.success == true) {
                    Messenger().post("Kurs skapad");
                    clearAll();
                }
            },
            error: function (err) {
                Messenger().post("Något gick fel");
            }
        });
    });

    $("#saveCourse").click(function () {
        var obj = {};
        if (!titleValid()) {
            Messenger().post("Titeln är ej godkänd");
            return;
        }

        obj.CourseName = $("#courseTitle").val();

        obj.CourseText = CKEDITOR.instances.editor1.getData();

        if (obj.CourseText.length > 3000) {
            $("#textError").text("Kursmeddelandets källkod får vara max 3000 tecken långt");
            Messenger().post("Kursmeddelande ej godkänt");
            return;
        }


        var teachersIds = $("#added").find(".courseTeachers");
        var tIds = [];
        for (i = 0; i < teachersIds.length; i++) {
            tIds.push(teachersIds.eq(i).val());
        }
        obj.TeachersAddedToCourse = tIds;

        var tasksIds = $("#addedTasks").find(".fullTask");
        var taskIds = [];
        for (i = 0; i < tasksIds.length; i++) {
            taskIds.push(tasksIds.eq(i).attr("id"));
        }
        obj.ChoosenTasks = taskIds;

        obj.CourseId = $("#courseIdt").val();

        $.ajax({
            url: 'SaveModifiedCourse',
            type: 'POST',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(obj),
            success: function (result) {
                if (result.success == true) {
                    Messenger().post("Ändringar sparade");
                }
            },
            error: function (err) {
                Messenger().post("Något gick fel");
            }
        });
    });

    $("#courseTitle").change(function () {
        titleValid();
    });

    function titleValid() {
        if ($("#courseTitle").val().length < 1) {
            $("#titleError").text("Du måste ange en titel");
            return false;
        }
        else if ($("#courseTitle").val().length > 20) {
            $("#titleError").text("Titeln får bestå av max 20tecken");
            return false;
        }
        else {
            $("#titleError").text("");
            return true;
        }
    };

    function clearAll() {
        $("#courseTitle").val("");
        CKEDITOR.instances.editor1.setData('');
        $("#addedTasks").html("");
    };
};