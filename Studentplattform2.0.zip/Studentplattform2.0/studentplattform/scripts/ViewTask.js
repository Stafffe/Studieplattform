﻿window.addEventListener('load', afterLoadFunction);
function afterLoadFunction() {
    var canSeeAnswer = false;

    if ($(".options").length == 0)
        canSeeAnswer = true;

    $("#sendAnswer").click(function () {
        if ($("#textOptionsInput").length > 0) {
            var correctText = $("#correctTextOptions").val().toLowerCase();
            var testAnswer = $("#testText").val().toLowerCase();
            if (correctText == testAnswer) {
                $("#textError").text("Rätt svar!");
                $("#textError").css("color", "green")
            }
            else {
                $("#textError").text("Fel svar!");
                $("#textError").css("color", "red")
            }
        }
        else if ($("#optionsInput").length > 0) {
            var correctAnswers = $(".correctOpt");
            var numberOfCorrectAnswers = correctAnswers.length;
            var correctAnswersArray = [];

            for(var i = 0; i < correctAnswers.length; i++)
            {
                correctAnswersArray.push(correctAnswers.eq(i).val());
            }

            var checkboxes = $(".correctCheck:checked");
            var markedAnswers = [];
            for (var i = 0; i < checkboxes.length; i++) {
                markedAnswers.push(checkboxes.eq(i).parent().prev().val());
            }

            if(numberOfCorrectAnswers == markedAnswers.length && JSON.stringify(correctAnswersArray) == JSON.stringify(markedAnswers))
            {
                $("#textError").text("Rätt svar!");
                $("#textError").css("color", "green")
            }
            else {
                $("#textError").text("Fel svar!");
                $("#textError").css("color", "red")
            }
        }

        canSeeAnswer = true;
    });

    $("#tUp").click(function () {
        $("#tUp").addClass("markedThumb");
        $("#tDown").removeClass("markedThumb");
    });

    $("#tDown").click(function(){
        $("#tDown").addClass("markedThumb");
        $("#tUp").removeClass("markedThumb");
    });

    var sliderHeight = "100px";
    var taskHeight = $("#task").height();
    var feedbackHeight = $("#feedback").height() + 220 + "px";

    $('#tips').click(function () {
        var tipsBtn = $('#tips');
        if (tipsBtn.attr("id") == "tips") {
            tipsBtn.removeAttr('id');
            if ($("#tipsDiv").is(":hidden")) {
                (taskHeight += $("#tipsDiv").height() + 40);
            }
            else
                taskHeight -= ($("#tipsDiv").height() + 40);

            $(".slider").eq(0).animate({ "height": taskHeight + "px" }, { duration: "slow" });
            $('#tipsDiv').slideToggle("slow").promise().done(function(){
                tipsBtn.attr("id", "tips");
            });
        }
    });

    $('#svar').click(function ()
    {
        if (canSeeAnswer == true) {
            var svarBtn = $('#svar');
            if (svarBtn.attr("id") == "svar") {
                svarBtn.removeAttr('id');
                if ($("#svarDiv").is(":hidden")) {
                    taskHeight += ($("#svarDiv").height() + 40);
                }
                else
                    taskHeight -= ($("#svarDiv").height() + 40);


                $(".slider").eq(0).animate({ "height": taskHeight + "px" }, { duration: "slow" });
                $('#svarDiv').slideToggle("slow").promise().done(function () {
                    svarBtn.attr("id", "svar");
                });
            }
        }
        else
            Messenger().post("Du måste gissa på ett rätt svar innan du kan se det lösningsförslaget");
    });

    $("#feedback").css("height", sliderHeight);
    $(".slider").eq(0).click(function () {
        if ($(".slider").eq(0).height() == 100) {
            openSlider1();
            $(".plus2").eq(0).hide();
            $(".plus2").eq(1).show();
            $(".slider").eq(1).addClass("hover");
            $(".slider").eq(0).removeClass("hover");
        }
    });
    $(".slider").eq(1).click(function () {
        if ($(".slider").eq(1).height() == 100) {
            openSlider2();
            $(".plus2").eq(1).hide();
            $(".plus2").eq(0).show();
            $(".slider").eq(0).addClass("hover");
            $(".slider").eq(1).removeClass("hover");
        }
    });

    function openSlider1() {
        $(".slider").eq(0).animate({ "height": taskHeight + "px" }, { duration: "slow" });
        $(".slider").eq(1).animate({ "height": sliderHeight }, { duration: "slow" });
    }

    function openSlider2() {
        $(".slider").eq(1).animate({ "height": feedbackHeight }, { duration: "slow" });
        $(".slider").eq(0).animate({ "height": sliderHeight }, { duration: "slow" });
    }


    $('#sendFeedback').click(function () {
        var obj = {};

        obj.Comment = CKEDITOR.instances.editor3.getData();

        if (obj.Comment.length > 3000) {
            $("#commentError").text("Kommentarens källkod får vara högst 3000tecken långt");
            return;
        }

        obj.CourseId = $("#courseId").val();
        
        if ($("#tUp").attr("class") == "markedThumb")
            var thumb = true;
        else if ($("#tDown").attr("class") == "markedThumb")
            var thumb = false;

        obj.Thumb = thumb;

        obj.Skala1 = $('input[name=feedbackScale1]:checked', '#1').val();
        obj.Skala2 = $('input[name=feedbackScale1]:checked', '#2').val();
        obj.SkalaOther = $('input[name=feedbackScale1]:checked', '#other').val();

        obj.TaskId = $("#taskId").val();

        $.ajax({
            type: 'POST',
            url: 'SendFeedback',
            dataType: 'json',
            contentType: "application/json; charset=utf-8",
            data: JSON.stringify(obj),
            success: function (result) {
                Messenger().post("Tack för din feedback!");
                $("#feedback").remove();
            },
            error: function (err) {
                Messenger().post("Något gick fel, kunde inte skicka feedback");
            }
        });
    });
}