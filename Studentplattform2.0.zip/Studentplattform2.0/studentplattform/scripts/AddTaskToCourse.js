﻿window.addEventListener('load', onloadFunction);
function onloadFunction() {

    $("#yourTasksBtn").click(function () {
        $("#searchTaskForCourse").hide();
        $("#yourTasks").slideDown("slow");
    });

    $("#searchTasks4CourseBtn").click(function () {
        $("#yourTasks").hide();
        $("#searchTaskForCourse").slideDown("slow");
    });

    $(".removeTask").click(function () {
        $(this).parent().parent().remove();
    });
}