﻿window.addEventListener('load', loadFunction);
function loadFunction() {
    var currentPerson = 1;
    var persons = $("#numberOfPersons").val();
    showPerson();

    function showPerson() {
        $(".personStatistic").hide();
        $("#person" + currentPerson).show();
        $(".previous").show();
        $(".next").show();
        if (currentPerson == 1)
        {
            $(".previous").hide();
        }
        else if (currentPerson == persons)
        {
            $(".next").hide();
        }
    };

    $(".next").click(function () {
        currentPerson++;
        showPerson();
    });

    $(".previous").click(function () {
        currentPerson--;
        showPerson();
    });
}