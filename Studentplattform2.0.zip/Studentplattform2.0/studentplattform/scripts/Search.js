﻿//Används även till NewCourse

window.addEventListener('load', loadFunction);
function loadFunction() {
    $(".menuButton").eq(0).attr("id", "clickedMenuButton");

    $(".oneSearchResult").click(function () {
        $('html,body').animate({ scrollTop: $("#tasks").offset().top }, 'slow');
    });

    function showMoreClicks() {
        //Klick på "Lägg till uppgifdel"-div
        var taskItemShowMore = $(".taskItem");

        taskItemShowMore.each(function () {
            if (!$(this).hasClass("haveShowMore")) {
                //var data = CKEDITOR.instances.editor2.getData();
                $(this).click(function () {
                    if ($(this).next().is(":hidden")) {
                        $(this).next().slideDown("slow");
                        $(this).find('.plus').attr("src", "/Images/Less.png");
                    } else {
                        $(this).next().slideUp("slow");
                        $(this).find(".plus").attr("src", "/Images/More.png")
                    }
                    $(this).addClass("haveShowMore");
                })
            }
        });

        $(".removeTask").click(function () {
            $(this).parent().parent().remove();
        });

        for (i = 0; i < $(".showTask").length; i++) {
            $(".showTask").eq(i).click(function () {
                var id = $(this).parent().find(".currentTaskId").first().val();
                window.location.href = '/MyTasks/ViewTask?taskId=' + id;
            });
        }
    };
    showMoreClicks();


    $("#searchBtn").click(function () {
        if ($("#searchCheckbox1").prop('checked') == true || $("#searchCheckbox1").attr("class") == null) {
            $("#tasks").html("");
            searchTasksByTitle($("#searchText").val());
        }

        $("#searchResults").html("");
        if ($("#searchCheckbox2").prop('checked') == true) 
            searchCourses($("#searchText").val());

        if ($("#searchCheckbox3").prop('checked') == true) 
            searchWriter($("#searchText").val());

        if ($("#searchCheckbox4").prop('checked') == true) 
            searchTags($("#searchText").val());

        $("#searchText").val("");
    });

    function searchCourses(searchCourse) {
        $.ajax({
            url: '/Search/SearchCourses',
            type: 'POST',
            data: { 'courseString': searchCourse },
            success: function (result) {
                var courseJson = JSON.parse(result);
                $("#searchResults").prepend('<b>Kurs-sökning på "' + searchCourse + '" gav ' + courseJson.length + ' träffar</b><br />');
                var courseString = "";
                for (i = 0; i < courseJson.length; i++) {
                    courseString += '<a href="../MyCourses/ShowCourse?courseId=' + courseJson[i].Id + '">';
                    courseString += '<div name="' + courseJson[i].Id + '" class="oneSearchResult course"><img class="searchResImg" src="/Images/Book.png" /><br />';
                    courseString += courseJson[i].Name + '</div></a>';
                }
                $("#searchResults").append(courseString);
            },
            error: function (err) {
                Messenger().post("Något gick fel med kurssökningen");
            }
        });
    };

    function searchTags(searchTag) {
        $.ajax({
            url: '/Search/SearchTags',
            type: 'POST',
            data: { 'tagString': searchTag },
            success: function (result) {
                var tagJson = JSON.parse(result);
                $("#searchResults").prepend('<b>Tagg-sökning på "' + searchTag + '" gav ' + tagJson.length + ' träffar</b><br />');
                var tagString = "";
                for (i = 0; i < tagJson.length; i++) {
                    tagString += '<div name="' + tagJson[i].Id + '" class="oneSearchResult tag"><img class="searchResImg" src="/Images/Tag.png" /><br />';
                    tagString += tagJson[i].Name + '</div>';
                }
                $("#searchResults").append(tagString);
                somePrep();
                $(".tag").click(function () {
                    searchTasksByTagg($(this).text());
                });
            },
            error: function (err) {
                Messenger().post("Något gick fel med taggsökningen");
            }
        });
    };

    function searchWriter(searchWriter) {
        $.ajax({
            url: '/Search/SearchWriters',
            type: 'POST',
            data: { 'writerString': searchWriter },
            success: function (result) {
                var writerJson = JSON.parse(result);
                $("#searchResults").prepend('<b>Författar-sökning på "' + searchWriter + '" gav ' + writerJson.length + ' träffar</b><br />');
                var writerString = "";
                for (i = 0; i < writerJson.length; i++) {
                    writerString += '<div name="' + writerJson[i].Id + '" class="oneSearchResult writer"><img class="searchResImg" src="/Images/Person.png" /><br />';
                    writerString += writerJson[i].Name + '</div>';
                }
                $("#searchResults").append(writerString);

                $(".writer").click(function () {
                    searchTasksByWriter($(this).text());
                });
                somePrep();
            },
            error: function (err) {
                Messenger().post("Något gick fel med författarsökningen");
            }
        });
    };

    function somePrep() {
        $(".oneSearchResult").click(function () {
            $('html,body').animate({ scrollTop: $("#tasks").offset().top }, 'slow');
        });
    }

    function searchTasksByTitle(searchString) {
        $.ajax({
            url: '/Search/SearchTasksByTitle',
            type: 'POST',
            data: { 'titleString': searchString },
            success: function (result) {
                var resultJson = JSON.parse(result);
                var showTasksStrings = '<b>Sökning på "' + searchString + '" gav ' + resultJson.length + ' träffar!</b><br />';
                for (i = 0; i < resultJson.length; i++) {
                    if ($("#addedTasks").find('[name="' + resultJson[i].Id + '"]').length == 0) {
                        showTasksStrings += '<div class="fullTask" id="' + resultJson[i].Id + '"><div class="taskItem';
                        if (resultJson[i].Finished == true)
                            showTasksStrings += ' taskItemGreen';
                        showTasksStrings += '"><div class="titleDiv">';
                        showTasksStrings += resultJson[i].Titel;
                        showTasksStrings += '</div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].Visningar;
                        showTasksStrings += '<img src="/Images/eye.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeUp;
                        showTasksStrings += '<img src="/Images/tUp.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeNer;
                        showTasksStrings += '<img src="/Images/tDown.png" class="taskInfoIcon" /></div><img id="tipsPlus" class="plus" src="/Images/More.png" /></div><div class="tipsBox"><div class="textInfoTask">Författare: <b>';
                        showTasksStrings += resultJson[i].Writer;
                        showTasksStrings += '</b><br />Antal klarade: <b>';
                        showTasksStrings += resultJson[i].AntalKlarade;
                        showTasksStrings += '</b><br />Svårighetsgrad-median: <b>';
                        if (resultJson[i].DiffMed != 0)
                            showTasksStrings += resultJson[i].DiffMed + '</b> av 4';
                        else
                            showTasksStrings += 'inga svar än</b>';
                        showTasksStrings += '<br />Kommentarer: <b>';
                        showTasksStrings += resultJson[i].NumberOfComments;
                        showTasksStrings += '</b><br />Taggar: <b>';
                        if (resultJson[i].TaggString != null)
                            showTasksStrings += resultJson[i].TaggString;
                        else
                            showTasksStrings += 'inga taggar';
                        showTasksStrings += '</b><br />Uppgifts-preview: <b>';
                        showTasksStrings += resultJson[i].Text + "</b>"
                        showTasksStrings += '</b><input type="hidden" class="currentTaskId" value="' + resultJson[i].Id + '" />';
                        if ($("#courseIdentifier").val() != "true")
                            showTasksStrings +=
                                '</input></div><input type="button" class="showTask btn btn-block btn-lg btn-primary" value="Visa uppgift" /></div>';
                        else
                            showTasksStrings +=
                                '</input></div><input type="button" class="addTask btn btn-block btn-lg btn-primary" name="' + resultJson[i].Id + '" value="Lägg till uppgift" /></div>';
                        showTasksStrings += "</div>"
                    }
                }
                $("#tasks").html(showTasksStrings);
                showMoreClicks();
                if ($("#courseIdentifier").val() == "true")
                    afterSearchPrep();
            },
            error: function () {
                Messenger().post("Problem med databasen");
            }
        });
    }

    function afterSearchPrep() {
        var tasksInList = $(".fullTask");

        var addTaskBtns = $(".addTask");

        $(".addTask").click(function (event) {
            var id = $(this).attr("name");
            //$(this).attr("class", "removeTask btn btn-block btn-lg btn-primary");
            $(this).attr("value", "Ta bort uppgift från kurs");
            $(this).attr("class", "");
            var thisTask = $(this).parent().parent();
            $("#addedTasks").append(thisTask);

            var btn = $(this)[0].outerHTML;
            $(this).remove();
            thisTask.children().eq(1).append(btn);
            $('[name="' + id + '"]').attr("class", "removeTask btn btn-block btn-lg btn-primary");
            $('[name="' + id + '"]').click(function () {
                $(this).parent().parent().remove();
            });
        });
    };


    $("#yourTasksBtn").click(function () {
        searchTasksByWriter(null);
    });

    function searchTasksByTagg(tagg) {
        $("#yourTasks").html("");
        $("#tasks").html("");
        $.ajax({
            url: '/Search/SearchTasksByTagg',
            type: 'POST',
            data: { 'taggString': tagg },
            success: function (result) {
                var resultJson = JSON.parse(result);
                var showTasksStrings = '<b>Sökning på tagg "' + tagg + '" gav ' + resultJson.length + ' träffar!</b><br />';
                for (i = 0; i < resultJson.length; i++) {
                    if ($("#addedTasks").find('[name="' + resultJson[i].Id + '"]').length == 0) {
                        showTasksStrings += '<div class="fullTask" id="' + resultJson[i].Id + '"><div class="taskItem';
                        if (resultJson[i].Finished == true)
                            showTasksStrings += ' taskItemGreen';
                        showTasksStrings += '"><div class="titleDiv">';
                        showTasksStrings += resultJson[i].Titel;
                        showTasksStrings += '</div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].Visningar;
                        showTasksStrings += '<img src="/Images/eye.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeUp;
                        showTasksStrings += '<img src="/Images/tUp.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeNer;
                        showTasksStrings += '<img src="/Images/tDown.png" class="taskInfoIcon" /></div><img id="tipsPlus" class="plus" src="/Images/More.png" /></div><div class="tipsBox"><div class="textInfoTask">Författare: <b>';
                        showTasksStrings += resultJson[i].Writer;
                        showTasksStrings += '</b><br />Antal klarade: <b>';
                        showTasksStrings += resultJson[i].AntalKlarade;
                        showTasksStrings += '</b><br />Svårighetsgrad-median: <b>';
                        if (resultJson[i].DiffMed != 0)
                            showTasksStrings += resultJson[i].DiffMed + '</b> av 4';
                        else
                            showTasksStrings += 'inga svar än</b>';
                        showTasksStrings += '<br />Kommentarer: <b>';
                        showTasksStrings += resultJson[i].NumberOfComments;
                        showTasksStrings += '</b><br />Taggar: <b>';
                        if (resultJson[i].TaggString != null)
                            showTasksStrings += resultJson[i].TaggString;
                        else
                            showTasksStrings += 'inga taggar';

                        showTasksStrings += '</b><br />Uppgifts-preview: <b>';
                        showTasksStrings += resultJson[i].Text + "</b>"
                        showTasksStrings += '</b><input type="hidden" class="currentTaskId" value="' + resultJson[i].Id + '" />';
                        if ($("#courseIdentifier").val() != "true")
                            showTasksStrings +=
                                '</input></div><input type="button" class="showTask btn btn-block btn-lg btn-primary" value="Visa uppgift" /></div>';
                        else
                            showTasksStrings +=
                                '</input></div><input type="button" class="addTask btn btn-block btn-lg btn-primary" name="' + resultJson[i].Id + '" value="Lägg till uppgift" /></div>';
                        showTasksStrings += "</div>"
                    }
                }
                $("#tasks").html(showTasksStrings);
                showMoreClicks();
            },
            error: function () {
                Messenger().post("Problem med databasen");
            }
        });
    }

    function searchTasksByWriter(writer) {
        $("#yourTasks").html("");
        $("#tasks").html("");
        $.ajax({
            url: '/Search/SearchTasksByWriter',
            type: 'POST',
            data: { 'writerString': writer },
            success: function (result) {
                var resultJson = JSON.parse(result);
                if (writer == null) {
                    var showTasksStrings = '<b>Sökning på författare gav ' + resultJson.length + ' träffar!</b><br />';
                }
                else
                    var showTasksStrings = '<b>Sökning på författare "' + writer + '" gav ' + resultJson.length + ' träffar!</b><br />';
                for (i = 0; i < resultJson.length; i++) {
                    if ($("#addedTasks").find('[name="' + resultJson[i].Id + '"]').length == 0) {
                        showTasksStrings += '<div class="fullTask" id="' + resultJson[i].Id + '"><div class="taskItem';
                        if (resultJson[i].Finished == true)
                            showTasksStrings += ' taskItemGreen';
                        showTasksStrings += '"><div class="titleDiv">';
                        showTasksStrings += resultJson[i].Titel;
                        showTasksStrings += '</div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].Visningar;
                        showTasksStrings += '<img src="/Images/eye.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeUp;
                        showTasksStrings += '<img src="/Images/tUp.png" class="taskInfoIcon" /></div><div class="taskInfoDiv">';
                        showTasksStrings += resultJson[i].TummeNer;
                        showTasksStrings += '<img src="/Images/tDown.png" class="taskInfoIcon" /></div><img id="tipsPlus" class="plus" src="/Images/More.png" /></div><div class="tipsBox"><div class="textInfoTask">Författare: <b>';
                        showTasksStrings += resultJson[i].Writer;
                        showTasksStrings += '</b><br />Antal klarade: <b>';
                        showTasksStrings += resultJson[i].AntalKlarade;
                        showTasksStrings += '</b><br />Svårighetsgrad-median: <b>';
                        if (resultJson[i].DiffMed != 0)
                            showTasksStrings += resultJson[i].DiffMed + '</b> av 4';
                        else
                            showTasksStrings += 'inga svar än</b>';
                        showTasksStrings += '<br />Kommentarer: <b>';
                        showTasksStrings += resultJson[i].NumberOfComments;
                        showTasksStrings += '</b><br />Taggar: <b>';
                        if (resultJson[i].TaggString != null)
                            showTasksStrings += resultJson[i].TaggString;
                        else
                            showTasksStrings += 'inga taggar';

                        showTasksStrings += '</b><br />Uppgifts-preview: <b>';
                        showTasksStrings += resultJson[i].Text + "</b>"
                        showTasksStrings += '</b><input type="hidden" class="currentTaskId" value="' + resultJson[i].Id + '" />';
                        if ($("#courseIdentifier").val() != "true")
                            showTasksStrings +=
                                '</input></div><input type="button" class="showTask btn btn-block btn-lg btn-primary" value="Visa uppgift" /></div>';
                        else
                            showTasksStrings +=
                                '</input></div><input type="button" class="addTask btn btn-block btn-lg btn-primary" name="' + resultJson[i].Id + '" value="Lägg till uppgift" /></div>';
                        showTasksStrings += "</div>"
                    }
                }
                if ($("#courseIdentifier").val() == "true")
                    $("#yourTasks").html(showTasksStrings);
                else
                    $("#tasks").html(showTasksStrings);
                showMoreClicks();
                if ($("#courseIdentifier").val() == "true")
                    afterSearchPrep();
            },
            error: function () {
                Messenger().post("Problem med databasen");
            }
        });
    };

};