﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class AllTeachers
    {
        public Teacher[] TeacherArray { get; set; }
        public int LoggedUserId { get; set; }

        //Kurs info
        public int[] TeachersAddedToCourse { get; set; }
        public String CourseName { get; set; }
        public String CourseText { get; set; }
        public int[] ChoosenTasks { get; set; }

        //Modify course
        public int CourseId { get; set; }
    }

    public class Teacher
    {
        public String Username { get; set; }
        public int Id { get; set; }
    }
}