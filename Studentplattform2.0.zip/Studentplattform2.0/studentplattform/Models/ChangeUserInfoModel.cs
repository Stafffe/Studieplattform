﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Studentplattform.Models
{
    public class ChangeUserInfoModel
    {
        public ChangeUserPassword PasswordModel { get; set; }
        public ChangeUserUsername UsernameModel { get; set; }
        public int ChangeWhat { get; set; }
    }

    public class ChangeUserPassword
    {

        [Required(ErrorMessage = "Du måste ange ditt gamla lösenord")]
        public String Password { get; set; }

        [Required(ErrorMessage = "Du måste ange ett nytt lösenord")]
        [StringLength(20, MinimumLength = 7, ErrorMessage = "Lösenordet måste vara mellan 7 och 20 tecken långt")]
        public String PasswordNew { get; set; }

        [Required(ErrorMessage = "Du måste upprepa ditt nya lösenord")]
        [System.ComponentModel.DataAnnotations.Compare("PasswordNew", ErrorMessage = "Lösenordet matchar inte")]
        public String RepeatNewPassword { get; set; }
    }

    public class ChangeUserUsername
    {
        [Required]
        public String Username { get; set; }
    }
}