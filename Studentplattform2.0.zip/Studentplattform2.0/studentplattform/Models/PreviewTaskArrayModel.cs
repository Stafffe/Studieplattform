﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class PreviewTaskArrayModel
    {
        public PreviewTaskModel[] PrevTasks { get; set; }
        public int TaskId { get; set; }
    }
}