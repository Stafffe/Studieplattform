﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Studentplattform.Models
{
    public class LoginUserModel
    {
        [Required(ErrorMessage = "Du måste skriva in din e-mailadress")]
        public String Email { get; set; }

        [Required(ErrorMessage = "Du måste ange ditt lösenord")]
        public String Password { get; set; }
    }
}