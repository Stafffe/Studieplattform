﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class CourseModel
    {
        public String Title { get; set; }
        public String Text { get; set; }
        public int Id { get; set; }
        public int[] Students { get; set; }
        public Users[] Teachers { get; set; }
        public bool CourseOwner { get; set; }
        public bool IsSubscribed { get; set; }
        public PreviewTaskArrayModel CourseTasks { get; set; }

        public bool IsAdmin { get; set; }

        //ModifyCourse
        public AllTeachers AllTeachers { get; set; }
    }
}