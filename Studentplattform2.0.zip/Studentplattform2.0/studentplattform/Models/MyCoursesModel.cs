﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class MyCoursesModel
    {
        public Courses[] MyOwnedCourses { get; set; }
        public Courses[] CoursesImIn { get; set; }
    }
}