﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class Task
    {
        public int? CourseId { get; set; }

        public String Title { get; set; }
        public String Text { get; set; }
        public String Tips { get; set; }
        public String Answer { get; set; }
        public String Image { get; set; }
        public String[] AnswerOptions { get; set; }
        public String[] CorrectAnswer { get; set; }
        public String TextOption { get; set; }
        public String[] FeedbackScale { get; set; }
        public String[] Tags { get; set; }

        public FeedbackScales[] FeedbackScaleEnt { get; set; }
        public answerOptions[] AnswerOptionsArray { get; set; }
        public String Writer { get; set; }
        public int Id { get; set; }
        public Boolean InCourse { get; set; }
        public int AntalVisningar { get; set; }
        public int AntalKlarade { get; set; }
        public Boolean[] Tummar { get; set; }
        public Comment[] Comments { get; set; }

        public bool CanMarkAsFinished { get; set; }
        public bool CanLeaveFeedback { get; set; }
        public bool IsWriter { get; set; }

        public bool IsAdmin { get; set; }
    }
}