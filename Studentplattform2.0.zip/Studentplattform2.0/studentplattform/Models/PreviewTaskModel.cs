﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class PreviewTaskModel
    {
        public int Id { get; set; }
        public String Titel { get; set; }
        public int Visningar { get; set; }
        public int TummeUp { get; set; }
        public int TummeNer { get; set; }
        public String Writer { get; set; }
        public int AntalKlarade { get; set; }
        public int[] Difficulty { get; set; }
        public int[] CouldBefore { get; set; }
        public int[] OtherQuestion { get; set; }
        public String OtherQuestionString { get; set; }
        public Comments[] Comments { get; set; }
        public String[] Tags { get; set; }
        public String Text { get; set; }
        public bool Finished { get; set; }

        public int DiffMed { get; set; }
        public int NumberOfComments { get; set; }
        public String TaggString { get; set; }

        public bool IsAdmin { get; set; }
    }
}