﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Studentplattform.Models
{
    public class RegisterUserModel
    {
        [Required(ErrorMessage = "Du måste skriva in en e-mailadress")]
        [EmailAddress(ErrorMessage = "Var god ange en giltig e-mailadress")]
        [Remote("IsEmailAvailable", "LoginRegister", ErrorMessage = "Emailadressen är redan registrerad")]
        public String Email { get; set; }

        [Required(ErrorMessage = "Du måste ange ett lösenord")]
        [StringLength(20, MinimumLength = 7, ErrorMessage = "Lösenordet måste vara mellan 7 och 20 tecken långt")]
        public String Password { get; set; }

        [Required(ErrorMessage = "Du måste upprepa ditt lösenord")]
        [System.ComponentModel.DataAnnotations.Compare("Password", ErrorMessage = "Lösenordet matchar inte")]
        public String RepeatPassword { get; set; }

        [Required(ErrorMessage = "Du måste skriva in ett användarnamn")]
        [Remote("IsUsernameAvailable", "LoginRegister", ErrorMessage = "Användarnamnet är upptaget")]
        public String Username { get; set; }
    }
}