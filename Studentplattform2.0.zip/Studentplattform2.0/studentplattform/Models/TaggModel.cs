﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class TaggModel
    {
        private StudieDbEntities db = new StudieDbEntities();

        public List<string> Search(string name)
        {
            return db.Tags.Where(t => t.Namn.StartsWith(name)).Select(p => p.Namn).ToList();
        }
    }
}