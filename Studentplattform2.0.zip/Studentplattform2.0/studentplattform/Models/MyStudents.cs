﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Studentplattform.Models
{
    public class MyStudents
    {
        public string CourseName { get; set; }
        public int CourseId { get; set; }
        public StudentActivities[] StudentActivitiesArray { get; set; }
    }

    public class StudentActivities
    {
        public int UserId { get; set; }
        public TaskFeedback[] TasksFeedback { get; set; }
    }

    public class TaskFeedback
    {
        public Tasks ThisTask { get; set; }
        public bool? Thumb { get; set; }
        public int? Difficulty { get; set; }
        public int? CouldBefore { get; set; }
        public string OtherGrade { get; set; }
        public int? OtherGradePoint { get; set; }
        [DisplayFormat(DataFormatString = "{yyyy mm-dd}")]
        public DateTime? DateForFeedBack { get; set; }

        public DateTime? MarkedAsDone { get; set; }
    }
}